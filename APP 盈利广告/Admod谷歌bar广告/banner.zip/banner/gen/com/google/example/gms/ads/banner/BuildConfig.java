/** Automatically generated file. DO NOT MODIFY */
package com.google.example.gms.ads.banner;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}