/** Automatically generated file. DO NOT MODIFY */
package com.spiritribe.mindplus;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}