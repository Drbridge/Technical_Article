package com.spiritribe.mindplus.http.file;

import android.database.sqlite.SQLiteOpenHelper;

import com.spiritribe.mindplus.http.BaseDBProvider;



public class EgmDBProvider extends BaseDBProvider {
	
	public static final String AUTHORITY ="com.netease.date";

	public EgmDBProvider() {
		super(AUTHORITY, EgmDBTables.TableNames);
	}

	@Override
	protected SQLiteOpenHelper getSQLiteOpenHelper() {
		return EgmDBOpenHelper.getInstance(getContext());
	}

}
