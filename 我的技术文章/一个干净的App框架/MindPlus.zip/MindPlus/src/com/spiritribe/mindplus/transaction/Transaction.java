package com.spiritribe.mindplus.transaction;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

import com.spiritribe.mindplus.transaction.listener.TransactionListener;
import com.spiritribe.mindplus.transaction.type.Priority;

public abstract class Transaction implements Runnable {

	private static short nextTransactionID;
	/**
	 * 类型
	 */
	private int mType;
	/**
	 * ID 唯一标示
	 */
	private int mID;
	/**
	 * 优先级
	 */
	private int mPriority;
	/**
	 * 是否序列
	 */
	private boolean mSerial;
	/**
	 * 弱引用，因为很可能会删掉，弱引用保证访问的安全
	 */
	private Reference<TransactionListener> mListener;
	private boolean isCancel;
	private TransactionEngine mTransMgr;
	private int mGroupID;

	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	protected Transaction(int type) {
		mType = type;
		mID = getNextTransactionId();
		mPriority = Priority.NORMAL;
		mSerial = true;
	}

	private synchronized static int getNextTransactionId() {
		if (nextTransactionID >= Short.MAX_VALUE) {
			nextTransactionID = 0;
		}
		return ++nextTransactionID;
	}

	public void setPriority(int priority) {
		mPriority = priority;
	}

	public int getType() {
		return mType;
	}

	public int getId() {
		return mID;
	}

	public TransactionEngine getTransactionEngine() {
		return mTransMgr;
	}

	public void setTransactionEngine(TransactionEngine transMgr) {
		mTransMgr = transMgr;
	}

	public void doEnd() {
		if (mTransMgr != null) {
			mTransMgr.endTransaction(this);
		}
	}

	public TransactionListener getListener() {
		return mListener != null ? mListener.get() : null;
	}

	public void setListener(TransactionListener listener) {
		mListener = new WeakReference<TransactionListener>(listener);
	}

	@Override
	public void run() {
		if (!isCancel()) {
			onTransact();
		} else {
			try {
				if (!isCancel()) {
					onTransact();
				}
			} catch (Exception e) {
				e.printStackTrace();

				doCancel();
				onTransactException(0, e);
			}

			// LocalTransaction 管理框架，执行完毕，就算结束，就可以清楚，如果是网络请求，网络另外开启Transaction
			mTransMgr.endTransaction(this);
		}
	}

	/**
	 * Transaction 执行异常.
	 * 
	 * @param e
	 */
	public void onTransactException(int errorCode, Exception e) {

	}

	/**
	 * Transaction 任务执行入口
	 */
	public abstract void onTransact();

	// Transaction执行成功，这里主要适用于界面的刷新
	public void notifyMessage(int msgCode, Object arg3) {
		TransactionListener listener = getListener();

		if (listener != null) {
			listener.onTransactionMessage(msgCode, mType, mID, arg3);
		}
	}

	protected void notifyMessage(int msgCode, int type, int tid, Object arg3) {
		TransactionListener listener = getListener();

		if (listener != null) {
			listener.onTransactionMessage(msgCode, type, tid, arg3);
		}
	}

	protected void notifyError(int errCode, int type, int tid, Object arg3) {
		TransactionListener listener = getListener();

		if (listener != null) {
			listener.onTransactionError(errCode, type, tid, arg3);
		}
	}

	public void notifyError(int errCode, Object arg3) {
		TransactionListener listener = getListener();
		if (listener != null) {
			listener.onTransactionError(errCode, mType, mID, arg3);
		}
	}

	/**
	 * 是否取消
	 * 
	 * @return 如果取消返回true,否则返回false
	 */
	public boolean isCancel() {
		return isCancel;
	}

	/**
	 * 取消事务
	 */
	public void doCancel() {
		isCancel = true;
	}

	public void setGroupID(int gid) {
		mGroupID = gid;
	}

	public int getGroupID() {
		return mGroupID;
	}

	public int getPriority() {
		// TODO Auto-generated method stub
		return mPriority;
	}
}
