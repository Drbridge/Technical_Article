package com.spiritribe.mindplus.activity;

import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.LoadingAdapterViewBaseWrap.OnLoadingListener;
import com.spiritribe.mindplus.R;
import com.spiritribe.mindplus.view.PullListView;

/**
 * @author 下拉刷新控件演示
 * 
 */
public class PullListViewTestTestActivity extends MplusBaseAcvitiy {

	private PullListView mListView;
	private Activity mActivity;
	private BaseAdapter mAdapter;
	private int count;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mActivity = this;
		setContentView(R.layout.activity_pull);
		mListView = (PullListView) findViewById(R.id.pull_listview);
		mAdapter = new MyAdatpter();
		mListView.setAdapter(mAdapter);
		mListView.enablePullFromStart();
		// mListView.disablePullToRefresh();
		mListView.setOnLoadingListener(new OnLoadingListener() {

			@Override
			public void onRefreshing() {

				mListView.onRefreshComplete();
				mListView.onLoadingComplete(true);
				count = 20;
				mAdapter.notifyDataSetChanged();

			}

			@Override
			public void onLoading() {
				count = 20;
				mAdapter.notifyDataSetChanged();
				mListView.onLoadingComplete(true);
			}

			@Override
			public void onLoadingMore() {
				count = count + 20;
				if (count > 100) {
					mListView.onLoadingComplete(false);
				} else {
					mListView.onLoadingComplete(true);
				}
				mAdapter.notifyDataSetChanged();

			}
		});
		mListView.load();
	}

	public static void startActivity(Context context) {
		Intent intent = new Intent(context, PullListViewTestTestActivity.class);
		if (!(context instanceof Activity)) {
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		}
		context.startActivity(intent);

	}

	private void iniView() {

	}

	class MyAdatpter extends BaseAdapter {

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			TextView textView = new TextView(parent.getContext());
			textView.setText("" + position);
			textView.setHeight(100);
			textView.setWidth(LayoutParams.MATCH_PARENT);
			textView.setGravity(Gravity.CENTER);
			return textView;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return count;
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

		iniView();
	}

	/**
	 * 不要采用匿名类，采用内部成员，这样能防止弱引用的时候被回收
	 */

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
}
