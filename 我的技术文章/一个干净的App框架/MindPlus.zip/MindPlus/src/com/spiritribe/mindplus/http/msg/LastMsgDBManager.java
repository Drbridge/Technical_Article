package com.spiritribe.mindplus.http.msg;

import java.util.LinkedList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.support.v4.util.LongSparseArray;
import android.text.TextUtils;
import android.util.Log;

import com.spiritribe.mindplus.http.BaseDBManager;
import com.spiritribe.mindplus.http.accout.ManagerAccount;
import com.spiritribe.mindplus.http.accout.ManagerAccount.Account;
import com.spiritribe.mindplus.http.msg.MsgDBTables.LastMsgTable;
import com.spiritribe.mindplus.http.msg.MsgDBTables.MsgTable;
import com.spiritribe.mindplus.loader.LoaderFactory;
import com.spiritribe.mindplus.utils.EgmConstants;
import com.spiritribe.mindplus.utils.EgmProtocolConstants;
import com.spiritribe.mindplus.utils.MemoryDataCenter;

public class LastMsgDBManager extends BaseDBManager {

	public static class NotificationMsg {
		public int chatCount;// 有新消息人数
		public int unreadNum;// 未读消息总数
		public int msgType;// 最新一条消息类型
		public ChatItemUserInfo user;// 聊天人，当仅有一个聊天人时，需要直接跳转到相应聊天窗口
		public String extra;// 系统消息的提示内容
		public boolean fire;
	}

	private static MsgDBProvider mDBProvider;

	private static MsgDBProvider getDBProvider() {
		MsgDBProvider provider = mDBProvider;
		if (provider == null) {
			provider = new MsgDBProvider();
			mDBProvider = provider;
		}
		return provider;
	}

	private static String[] Projection_Uid = new String[] { MsgDBTables.LastMsgTable.C_ANOTHERID };

	private static ContentValues[] makeInsertValues(List<ChatItemInfo> list) {
		ContentValues[] array = new ContentValues[list.size()];
		for (int i = 0; i < list.size(); i++) {
			ContentValues values = makeInsertValue(list.get(i));
			array[i] = values;
		}
		return array;
	}

	/**
	 * 生成消息插入ContentValues
	 * 
	 * @param itemInfo
	 * @return
	 */
	private static ContentValues makeInsertValue(ChatItemInfo itemInfo) {
		ContentValues values = new ContentValues();

		long currentUid = -1;
		if (null != MemoryDataCenter.getInstance().get(MemoryDataCenter.CURRENT_CHAT_UID)) {
			currentUid = (Long) MemoryDataCenter.getInstance().get(MemoryDataCenter.CURRENT_CHAT_UID);
		}
		if (currentUid == itemInfo.anotherUserInfo.uid) {// 当前聊天人，直接已读
			values.put(LastMsgTable.C_UNREADNUM, 0);
		} else {
			values.put(LastMsgTable.C_UNREADNUM, itemInfo.notReadCount);
		}
		// 处理 MessageInfo
		long me = Long.valueOf(ManagerAccount.getInstance().getCurrentAccountId());
		if (me == itemInfo.message.receiver) {// another 为聊天对方
			values.put(LastMsgTable.C_ANOTHERID, itemInfo.message.sender);
		} else {
			values.put(LastMsgTable.C_ANOTHERID, itemInfo.message.receiver);
		}
		values.put(LastMsgTable.C_FROMID, itemInfo.message.sender);
		values.put(LastMsgTable.C_TIME, itemInfo.message.time);

		itemInfo.message.setEncrypted();
		values.put(LastMsgTable.C_CONTENT, PDEEngine.PXEncrypt(itemInfo.message.msgContent));

		if (null != itemInfo.message.mediaUrl) {
			values.put(LastMsgTable.C_MEDIA_URL, itemInfo.message.mediaUrl);
		}
		values.put(LastMsgTable.C_TYPE, itemInfo.message.type);
		values.put(LastMsgTable.C_MSGID, itemInfo.message.msgId);
		values.put(LastMsgTable.C_DURATION, itemInfo.message.duration);
		values.put(LastMsgTable.C_EXTRA_ID, itemInfo.message.extraId);
		if (null == itemInfo.message.extraString && itemInfo.message.extra != null) {
			itemInfo.message.extraString = itemInfo.message.extra.toString();
		}

		if (null != itemInfo.message.extraString) {
			values.put(LastMsgTable.C_EXTRA, itemInfo.message.extraString);
		}
		values.put(LastMsgTable.C_USERCP, itemInfo.message.usercp);

		// 对方发送来的消息，直接将状态设置为发送成功
		if (itemInfo.message.sender != ManagerAccount.getInstance().getCurrentId()) {
			values.put(LastMsgTable.C_STATUS, EgmConstants.Sending_State.SEND_SUCCESS);
		} else {
			if (itemInfo.message.status >= 0) {
				values.put(LastMsgTable.C_STATUS, itemInfo.message.status);
			} else {
				values.put(LastMsgTable.C_STATUS, EgmConstants.Sending_State.SEND_SUCCESS);
			}
		}

		if (null != itemInfo.message.attach) {
			values.put(LastMsgTable.C_ATTACH, itemInfo.message.attach);
		}

		// 处理 ChatItemUserInfo
		values.put(LastMsgTable.C_ANOTHERID, itemInfo.anotherUserInfo.uid);
		values.put(LastMsgTable.C_ISVIP, itemInfo.anotherUserInfo.isVip ? 1 : 0);
		values.put(LastMsgTable.C_ISNEW, itemInfo.anotherUserInfo.isNew ? 1 : 0);
		values.put(LastMsgTable.C_CROWNID, itemInfo.anotherUserInfo.crownId);
		if (null != itemInfo.anotherUserInfo.nick) {
			values.put(LastMsgTable.C_NICK, itemInfo.anotherUserInfo.nick);
		}
		if (null != itemInfo.anotherUserInfo.portraitUrl192) {
			values.put(LastMsgTable.C_AVATAR, itemInfo.anotherUserInfo.portraitUrl192);
		}

		values.put(LastMsgTable.C_RESERVED3, itemInfo.message.getReserved3());

		values.put(LastMsgTable.C_RESERVED2, itemInfo.message.getFaceId());

		values.put(LastMsgTable.C_RESERVED1, "" + itemInfo.notReadGiftValue);

		values.put(LastMsgTable.C_INTERGER1, itemInfo.anotherUserInfo.hasStared ? 1 : 0);

		return values;
	}

	/**
	 * 往最后一条消息列表中插入一项
	 */
	public static void insertChatItemInfo(ChatItemInfo itemInfo) {
		if (null == itemInfo || null == itemInfo.message || null == itemInfo.anotherUserInfo) {
			return;
		}
		ContentValues values = makeInsertValue(itemInfo);
		if (values != null) {
			getDBProvider().insert(LastMsgTable.CONTENT_URI, values);
		}
	}

	/**
	 * 往最后一条消息列表中插入一项，并同时设置豪气值、亲密度
	 */
	public static void insertChatItemInfo(ChatItemInfo itemInfo, long rich, long intimacy) {
		if (null == itemInfo || null == itemInfo.message || null == itemInfo.anotherUserInfo) {
			return;
		}
		ContentValues values = makeInsertValue(itemInfo);
		values.put(LastMsgTable.C_RICH, rich);
		values.put(LastMsgTable.C_INTIMACY, intimacy);
		if (values != null) {
			getDBProvider().insert(LastMsgTable.CONTENT_URI, values);
		}
	}

	/**
	 * 处理push过来的新消息 单条消息处理
	 */
	public static void handelNewMsg(ChatItemInfo itemInfo) {
		if (null == itemInfo || null == itemInfo.anotherUserInfo) {
			return;
		}
		String selection = LastMsgTable.C_ANOTHERID + "=?";
		String[] selectionArgs = new String[] { String.valueOf(itemInfo.anotherUserInfo.uid) };
		Cursor c = getDBProvider().query(LastMsgTable.CONTENT_URI, new String[] { LastMsgTable._ID }, selection,
				selectionArgs, null);
		try {
			if (c != null && c.getCount() > 0) {
				updateLastMsg(itemInfo);
			} else {
				insertChatItemInfo(itemInfo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (c != null) {
				c.close();
				c = null;
			}
		}
	}

	/**
	 * 发送消息更新状态使用
	 * 
	 * @param msgInfo
	 */
	public static void handleNewMsg(MessageInfo msgInfo) {
		if (ManagerAccount.getInstance().getCurrentAccount() == null)
			return;
		long currentUid = ManagerAccount.getInstance().getCurrentId();
		long anotherUid;
		if (currentUid == msgInfo.sender) {
			anotherUid = msgInfo.receiver;
		} else {
			anotherUid = msgInfo.sender;
		}
		ChatItemInfo chatItemInfo = getChatItemByUid(anotherUid);
		if (chatItemInfo != null) {
			chatItemInfo.notReadCount = 0;
			chatItemInfo.message = msgInfo;

			handelNewMsg(chatItemInfo);
		}
	}

	/**
	 * 按uid查询ChatItemInfo uid
	 */
	public static ChatItemInfo getChatItemByUid(long uid) {
		ChatItemInfo itemInfo = null;
		String selection = LastMsgTable.C_ANOTHERID + "=?";
		String[] selectionArgs = new String[] { String.valueOf(uid) };
		Cursor c = getDBProvider().query(LastMsgTable.CONTENT_URI, null, selection, selectionArgs, null);
		if (c == null) {
			return itemInfo;
		}

		if (c.moveToFirst()) {
			itemInfo = new ChatItemInfo();
			itemInfo.notReadCount = c.getInt(c.getColumnIndex(LastMsgTable.C_UNREADNUM));
			try {
				itemInfo.notReadGiftValue = Integer.valueOf(c.getString(c.getColumnIndex(LastMsgTable.C_RESERVED1)));
			} catch (Exception e) {
			}

			itemInfo.anotherUserInfo.uid = c.getLong(c.getColumnIndex(LastMsgTable.C_ANOTHERID));
			itemInfo.anotherUserInfo.crownId = c.getInt(c.getColumnIndex(LastMsgTable.C_CROWNID));
			itemInfo.anotherUserInfo.isNew = c.getInt(c.getColumnIndex(LastMsgTable.C_ISNEW)) == 1 ? true : false;
			itemInfo.anotherUserInfo.isVip = c.getInt(c.getColumnIndex(LastMsgTable.C_ISVIP)) == 1 ? true : false;
			itemInfo.anotherUserInfo.nick = c.getString(c.getColumnIndex(LastMsgTable.C_NICK));
			itemInfo.anotherUserInfo.portraitUrl192 = c.getString(c.getColumnIndex(LastMsgTable.C_AVATAR));

			itemInfo.message.sender = c.getLong(c.getColumnIndex(LastMsgTable.C_FROMID));
			long another = c.getLong(c.getColumnIndex(LastMsgTable.C_ANOTHERID));
			if (itemInfo.message.sender == another) {
				itemInfo.message.receiver = Long.valueOf(ManagerAccount.getInstance().getCurrentAccountId());
			} else {
				itemInfo.message.receiver = another;
			}
			itemInfo.message.time = c.getLong(c.getColumnIndex(LastMsgTable.C_TIME));
			itemInfo.message.setReserved3(c.getInt(c.getColumnIndex(LastMsgTable.C_RESERVED3)));

			String content = c.getString(c.getColumnIndex(LastMsgTable.C_CONTENT));
			if (itemInfo.message.isEncrypted()) {
				itemInfo.message.msgContent = PDEEngine.PXDecrypt(content);
			} else {
				itemInfo.message.msgContent = content;
			}

			itemInfo.message.mediaUrl = c.getString(c.getColumnIndex(LastMsgTable.C_MEDIA_URL));
			itemInfo.message.type = c.getInt(c.getColumnIndex(LastMsgTable.C_TYPE));
			itemInfo.message.msgId = c.getLong(c.getColumnIndex(LastMsgTable.C_MSGID));
			itemInfo.message.duration = c.getInt(c.getColumnIndex(LastMsgTable.C_DURATION));
			itemInfo.message.extraId = c.getLong(c.getColumnIndex(LastMsgTable.C_EXTRA_ID));
			itemInfo.message.extraString = c.getString(c.getColumnIndex(LastMsgTable.C_EXTRA));
			itemInfo.message.usercp = c.getInt(c.getColumnIndex(LastMsgTable.C_USERCP));
			itemInfo.message.attach = c.getString(c.getColumnIndex(LastMsgTable.C_ATTACH));
			itemInfo.message.status = c.getInt(c.getColumnIndex(LastMsgTable.C_STATUS));

			itemInfo.message.faceId = c.getString(c.getColumnIndex(LastMsgTable.C_RESERVED2));

			itemInfo.anotherUserInfo.hasStared = c.getInt(c.getColumnIndex(LastMsgTable.C_INTERGER1)) == 1 ? true
					: false;

		}
		c.close();

		return itemInfo;
	}

	/**
	 * 更新最后一条消息列表
	 */
	public static boolean updateLastMsg(ChatItemInfo itemInfo) {
		if (null == itemInfo || null == itemInfo.anotherUserInfo || null == itemInfo.message) {
			return false;
		}
		ContentValues values = makeInsertValue(itemInfo);
		String selection = LastMsgTable.C_ANOTHERID + "=?";

		String[] selectionArgs = new String[] { String.valueOf(itemInfo.anotherUserInfo.uid) };
		int ret = getDBProvider().update(LastMsgTable.CONTENT_URI, values, selection, selectionArgs);
		return ret > 0;
	}

	/**
	 * 更新最后一条消息列表为空消息 当与一个用户的消息表为空时，消息列表保留与该用户的一条消息，使得消息列表能现实该用户。但该消息的内容为空。
	 */
	public static boolean updateLastMsgToEmpty(long uid) {
		ContentValues values = new ContentValues();
		values.put(LastMsgTable.C_TYPE, EgmProtocolConstants.MSG_TYPE.MSG_TYPE_TEXT);
		values.put(LastMsgTable.C_CONTENT, "");
		values.put(LastMsgTable.C_STATUS, EgmConstants.Sending_State.SEND_SUCCESS);
		values.put(LastMsgTable.C_RESERVED3, 0);

		String selection = LastMsgTable.C_ANOTHERID + "=?";

		String[] selectionArgs = new String[] { String.valueOf(uid) };
		int ret = getDBProvider().update(LastMsgTable.CONTENT_URI, values, selection, selectionArgs);
		return ret > 0;
	}

	/**
	 * 查询Notificationbar提醒所需数据 excludeUid 排除掉当前聊天人
	 */
	public static NotificationMsg getNotificationMsg(long excludeUid) {
		String[] selectionArgs = null;
		String selection = null;
		if (excludeUid > 0) {
			selection = LastMsgTable.C_UNREADNUM + " >?" + " AND " + LastMsgTable.C_ANOTHERID + " <>?";
			selectionArgs = new String[] { String.valueOf(0), String.valueOf(excludeUid) };
		} else {
			selection = LastMsgTable.C_UNREADNUM + " >?";
			selectionArgs = new String[] { String.valueOf(0), };
		}

		Cursor c = getDBProvider().query(LastMsgTable.CONTENT_URI, null, selection, selectionArgs,
				LastMsgTable.C_TIME + " DESC");
		NotificationMsg notify = null;
		try {
			if (c != null && c.getCount() > 0) {
				notify = new NotificationMsg();

				if (c.moveToFirst()) {// 取最后一条消息的User
					notify.chatCount = c.getCount();
					notify.msgType = c.getInt(c.getColumnIndex(LastMsgTable.C_TYPE));

					String content = c.getString(c.getColumnIndex(LastMsgTable.C_CONTENT));
					int reserve3 = c.getInt(c.getColumnIndex(LastMsgTable.C_RESERVED3));

					if (((reserve3 >> 10) & 0x1) != 0) {
						content = PDEEngine.PXDecrypt(content);
					}

					notify.extra = content;
					notify.unreadNum += c.getInt(c.getColumnIndex(LastMsgTable.C_UNREADNUM));
					notify.fire = (c.getInt(c.getColumnIndex(LastMsgTable.C_RESERVED3)) & 0x01) != 0;

					ChatItemUserInfo itemInfo = new ChatItemUserInfo();
					itemInfo.uid = c.getLong(c.getColumnIndex(LastMsgTable.C_ANOTHERID));
					itemInfo.crownId = c.getInt(c.getColumnIndex(LastMsgTable.C_CROWNID));
					itemInfo.isNew = c.getInt(c.getColumnIndex(LastMsgTable.C_ISNEW)) == 1 ? true : false;
					itemInfo.isVip = c.getInt(c.getColumnIndex(LastMsgTable.C_ISVIP)) == 1 ? true : false;
					itemInfo.nick = c.getString(c.getColumnIndex(LastMsgTable.C_NICK));
					itemInfo.portraitUrl192 = c.getString(c.getColumnIndex(LastMsgTable.C_AVATAR));
					itemInfo.hasStared = c.getInt(c.getColumnIndex(LastMsgTable.C_INTERGER1)) == 1 ? true : false;
					notify.user = itemInfo;
				}

				for (c.moveToNext(); !c.isAfterLast(); c.moveToNext()) {// 所有未读消息数
					notify.unreadNum += c.getInt(c.getColumnIndex(LastMsgTable.C_UNREADNUM));
				}
			}
		} finally {
			if (c != null) {
				c.close();
			}
			c = null;
		}
		return notify;
	}

	/**
	 * 获取最近消息列表
	 * 
	 * @return
	 */
	public static Cursor getLastMsgList(int chooseType) {
		Cursor cursor = null;

		StringBuilder selection = new StringBuilder();
		if (chooseType == LoaderFactory.CHAT_LIST_CHOOSE_NEW) {
			selection.append(LastMsgTable.C_ISNEW).append(" = 1");
		} else if (chooseType == LoaderFactory.CHAT_LIST_CHOOSE_STAR) {
			selection.append(LastMsgTable.C_INTERGER1).append(" = 1");
		}
		StringBuilder sortOrder = new StringBuilder();
		sortOrder.append(" CAST ( ").append(MsgDBTables.LastMsgTable.C_RESERVED1).append(" AS INT ) ").append(" DESC")
				.append(" , ");
		sortOrder.append(MsgDBTables.LastMsgTable.C_TIME).append(" DESC");
		String orderBy = sortOrder.toString();
		cursor = getDBProvider().query(LastMsgTable.CONTENT_URI, ChatListMeta.Projection, selection.toString(), null,
				orderBy);
		return cursor;
	}

	/**
	 * @return
	 */
	public static Cursor getLastMsgListAsUids(long[] uids, int chooseType) {
		Cursor cursor = null;

		StringBuilder uidStr = new StringBuilder();
		uidStr.append("(");
		for (long uid : uids) {
			uidStr.append(String.valueOf(uid)).append(",");
		}
		uidStr.deleteCharAt(uidStr.length() - 1);
		uidStr.append(")");

		StringBuilder where = new StringBuilder();
		where.append(MsgDBTables.LastMsgTable.C_ANOTHERID).append(" IN ").append(uidStr.toString());

		if (chooseType == LoaderFactory.CHAT_LIST_CHOOSE_NEW) {
			where.append(" AND ").append(LastMsgTable.C_ISNEW).append(" = 1");
		}

		cursor = getDBProvider().query(LastMsgTable.CONTENT_URI, ChatListMeta.Projection, where.toString(), null, null);
		return cursor;
	}

	/**
	 * 根据uid获取豪气值和亲密度
	 * 
	 * @param uid
	 * @return long[] long[0]:豪气值 long[1]:亲密度
	 */
	public static long[] getRichAndIntimacyByUid(long uid) {
		long[] values = new long[2];
		String[] projection = new String[] { LastMsgTable.C_RICH, LastMsgTable.C_INTIMACY };
		String selection = LastMsgTable.C_ANOTHERID + "=?";
		String[] selectionArgs = new String[] { String.valueOf(uid) };
		Cursor c = getDBProvider().query(LastMsgTable.CONTENT_URI, projection, selection, selectionArgs, null);
		if (c != null) {
			try {
				if (c.moveToFirst()) {
					values[0] = c.getLong(c.getColumnIndex(LastMsgTable.C_RICH));
					values[1] = c.getLong(c.getColumnIndex(LastMsgTable.C_INTIMACY));
				}
			} finally {
				c.close();
				c = null;
			}
		}
		return values;
	}

	public static boolean isExistMsgByMsgId(long fromId, long msgId) {
		boolean isExist = false;
		String[] projection = new String[] {};
		StringBuilder selection = new StringBuilder();
		selection.append(MsgTable.C_FROMID).append("=?").append(" AND ").append(MsgTable.C_MSGID).append("=?");
		String[] selectionArgs = new String[] { String.valueOf(fromId), String.valueOf(msgId) };
		Cursor c = getDBProvider().query(LastMsgTable.CONTENT_URI, projection, selection.toString(), selectionArgs,
				null);
		if (c != null) {
			try {
				if (c.moveToFirst()) {
					isExist = true;
				}
			} finally {
				c.close();
				c = null;
			}
		}
		return isExist;
	}

	/**
	 * 更新豪气值和亲密度
	 * 
	 * @param values
	 * @param rich
	 */
	public static void updateRichOrIntimacy(ChatSortKeyValue[] values, boolean rich) {
		if (values == null || values.length == 0) {
			return;
		}

		StringBuilder selection = new StringBuilder();
		selection.append(LastMsgTable.C_ANOTHERID).append("=?");

		StringBuffer buffer = new StringBuffer();
		buffer.append("UPDATE ").append(LastMsgTable.TABLE_NAME).append(" SET ");

		if (rich) {
			buffer.append(LastMsgTable.C_RICH);
		} else {
			buffer.append(LastMsgTable.C_INTIMACY);
		}

		buffer.append("=?").append(" WHERE ").append(LastMsgTable.C_ANOTHERID).append("=?");

		SQLiteOpenHelper openHelper = getDBProvider().getSQLiteOpenHelper();
		SQLiteDatabase database = openHelper.getWritableDatabase();

		SQLiteStatement update = database.compileStatement(buffer.toString());
		buffer.setLength(0);

		database.beginTransaction();

		try {
			for (ChatSortKeyValue value : values) {
				update.bindLong(1, value.sorVvalue);
				update.bindLong(2, value.uid);

				update.execute();
			}

			database.setTransactionSuccessful();
		} catch (Exception e) {
		}

		database.endTransaction();
	}

	/**
	 * 根据豪气值排序
	 * 
	 * @param onlyNew
	 * @return
	 */
	public static Cursor getLastMsgListSortByRich(int chooseType, boolean rich) {
		Cursor cursor = null;

		StringBuilder where = new StringBuilder();
		if (chooseType == LoaderFactory.CHAT_LIST_CHOOSE_NEW) {
			where.append(LastMsgTable.C_ISNEW).append(" = 1");
		} else if (chooseType == LoaderFactory.CHAT_LIST_CHOOSE_STAR) {
			where.append(LastMsgTable.C_INTERGER1).append(" = 1");
		}

		StringBuilder sort = new StringBuilder();
		if (rich) {
			sort.append(LastMsgTable.C_RICH).append(" DESC");
		} else {
			sort.append(LastMsgTable.C_INTIMACY).append(" DESC");
		}
		cursor = getDBProvider().query(LastMsgTable.CONTENT_URI, ChatListMeta.Projection, where.toString(), null,
				sort.toString());
		return cursor;
	}

	/**
	 * 获取聊天人列表中所有uid
	 * 
	 * @return
	 */
	public static long[] getUids() {
		Cursor c = getDBProvider().query(LastMsgTable.CONTENT_URI, Projection_Uid, null, null, null);
		long[] uids = null;
		if (c != null) {
			uids = new long[c.getCount()];
			int i = 0;
			if (c != null) {
				while (c.moveToNext()) {
					uids[i++] = c.getLong(c.getColumnIndex(MsgDBTables.LastMsgTable.C_ANOTHERID));
				}
				c.close();
				c = null;
			}
		}
		return uids;
	}

	/**
	 * 删除一条消息
	 * 
	 * @param msgId
	 */
	public static int delMsg(long msgId) {
		StringBuilder selection = new StringBuilder();
		selection.append(LastMsgTable.C_MSGID).append("=?");

		String[] args = new String[] { String.valueOf(msgId) };
		int row = getDBProvider().delete(LastMsgTable.CONTENT_URI, selection.toString(), args);
		return row;
	}

	/**
	 * 删除一条消息
	 * 
	 * @param uid
	 */
	public static void delMsgByUid(long uid) {
		StringBuilder selection = new StringBuilder();
		selection.append(LastMsgTable.C_ANOTHERID).append("=?");

		String[] args = new String[] { String.valueOf(uid) };
		getDBProvider().delete(LastMsgTable.CONTENT_URI, selection.toString(), args);
	}

	/**
	 * 设置未读消息数目为0
	 * 
	 * @param uid
	 */
	public static void setUnReadNumZero(long uid) {

		ChatItemInfo chatItemInfo = getChatItemByUid(uid);
		if (chatItemInfo == null) {
			return;
		}

		StringBuilder selection = new StringBuilder();
		selection.append(LastMsgTable.C_ANOTHERID).append("=?");

		String[] args = new String[] { String.valueOf(uid) };

		ContentValues values = new ContentValues();
		values.put(LastMsgTable.C_UNREADNUM, 0);
		values.put(LastMsgTable.C_RESERVED1, 0);

		if (chatItemInfo.notReadGiftValue > 0) {
			values.put(MsgTable.C_TIME, System.currentTimeMillis());
		}

		getDBProvider().update(LastMsgTable.CONTENT_URI, values, selection.toString(), args);
	}

	/**
	 * 把所有消息设置成已读
	 * 
	 * @param uid
	 */
	public static void setAllUnReadNumZero() {
		ContentValues values = new ContentValues();
		values.put(LastMsgTable.C_UNREADNUM, 0);
		values.put(LastMsgTable.C_RESERVED1, 0);
		getDBProvider().update(LastMsgTable.CONTENT_URI, values, null, null);
	}

	/**
	 * 加星用户/取消加星用户
	 * 
	 * @param uid
	 */
	public static void setStar(long uid, int type) {

		ChatItemInfo chatItemInfo = getChatItemByUid(uid);
		if (chatItemInfo == null) {
			return;
		}

		StringBuilder selection = new StringBuilder();
		selection.append(LastMsgTable.C_ANOTHERID).append("=?");

		String[] args = new String[] { String.valueOf(uid) };

		ContentValues values = new ContentValues();
		values.put(LastMsgTable.C_INTERGER1, type);

		getDBProvider().update(LastMsgTable.CONTENT_URI, values, selection.toString(), args);
	}

	/**
	 * 获取未读消息总数
	 * 
	 * @return
	 */
	public static int getUnReadNum() {
		int count = 0;
		Cursor c = getDBProvider().query(LastMsgTable.CONTENT_URI, new String[] { LastMsgTable.C_UNREADNUM }, null,
				null, null);
		if (c == null || c.getCount() == 0) {
			return count;
		}
		// 注意，要查询的列记得出现在projection中
		try {
			while (c.moveToNext()) {
				int unReadNum = Integer.parseInt(c.getString(c.getColumnIndex(LastMsgTable.C_UNREADNUM)));
				count = count + unReadNum;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (c != null) {
				c.close();
				c = null;
			}
		}
		return count;
	}

	public static void updateLasgMsgList(List<ChatItemInfo> remoteList) {
		// long startTs = System.currentTimeMillis();
		// long tempTs = startTs;

		Account account = ManagerAccount.getInstance().getCurrentAccount();
		if (account == null) {
			return;
		}

		// remoteList为空，是用户在别的机器上把所有聊天消息删除了——所以，本地也同样删除全部消息；
		// 发送失败的消息是只保存在本地的，服务器上没有的，是本机器独有的——所以，留下发送失败的消息
		if (remoteList == null || remoteList.size() == 0) {
			getDBProvider().delete(LastMsgTable.CONTENT_URI, LastMsgTable.C_STATUS + " <> 2", null);
			return;
		}

		// 查询本地数据库，把所有本地的消息保存在localList中
		LongSparseArray<MessageInfo> localList = new LongSparseArray<MessageInfo>();
		Cursor cursor = getDBProvider().query(LastMsgTable.CONTENT_URI, MessageInfo.SimpleProject, null, null, null);
		if (cursor != null) {
			if (cursor.moveToFirst()) {
				do {
					MessageInfo info = new MessageInfo(cursor, MessageInfo.T_C_SIMPLE);
					localList.put(info.getReceiver(), info);
				} while (cursor.moveToNext());
			}
			cursor.close();
		}

		// keepList保存localList中需要保留的消息id，其他的local消息会从数据库中删除
		LinkedList<Long> keepList = new LinkedList<Long>();

		// 1.数据库操作前的准备——一次remoteList遍历操作、一次剩余的localList遍历操作
		// if (remoteChatItemInfo.notReadCount > 0) {
		// 服务器有新的消息（本地没有进去过聊天详情页，否则notReadCount是0），使用服务器的消息，删除本地的消息；
		// } else {
		// if (localMessageInfo == null) {
		// 表示本地没有对应的消息（在别的机器上查看的消息），把remoteChatItemInfo的内容设置为空文本消息
		// } else {
		// if (localMessageInfo的状态是发送失败) {
		// if (localMessageInfo的时间比较新) {
		// 以localMessageInfo为准
		// } else {
		// 以remoteChatItemInfo为准
		// }
		// } else {
		// if
		// (localMessageInfo为空文本消息，而且remoteChatItemInfo的时间小于等于localMessageInfo)
		// {
		// 以localMessageInfo为准
		// }
		// } else {
		// 以remoteChatItemInfo为准
		// }
		// }
		// }

		for (int i = remoteList.size() - 1; i >= 0; i--) {
			ChatItemInfo remoteChatItemInfo = remoteList.get(i);
			long userId = remoteChatItemInfo.anotherUserInfo.uid;
			if (remoteChatItemInfo.notReadCount > 0) {
				localList.delete(userId);
			} else {
				MessageInfo localMessageInfo = localList.get(userId);
				if (localMessageInfo == null) {
					remoteChatItemInfo.message.msgId = 0;
					remoteChatItemInfo.message.type = EgmProtocolConstants.MSG_TYPE.MSG_TYPE_TEXT;
					remoteChatItemInfo.message.msgContent = "";
					remoteChatItemInfo.message.setReserved3(0); // 剔除阅后即焚的状态
				} else {
					if (localMessageInfo.status == EgmConstants.Sending_State.SEND_FAIL) {
						if (remoteChatItemInfo.message.time < localMessageInfo.time) {
							keepList.add(userId);
							remoteList.remove(i);
							localList.remove(userId);
							continue;
						} else {
							localList.remove(userId);
							continue;
						}
					} else if (localMessageInfo.msgId == 0 && remoteChatItemInfo.message.time <= localMessageInfo.time) {
						keepList.add(userId);
						remoteList.remove(i);
						localList.remove(userId);
						continue;
					} else {
						localList.remove(userId);
					}
				}
			}
		}

		// 遍历剩余的localList，把其中发送失败的消息保存也到keepList中
		for (int i = 0; i < localList.size(); i++) {
			MessageInfo messageInfo = localList.valueAt(i);
			if (messageInfo.status == EgmConstants.Sending_State.SEND_FAIL) {
				keepList.add(messageInfo.msgId);
			}
		}

		// Log.e("updateLasgMsgList",
		// "1---------"+(System.currentTimeMillis()-tempTs));
		// tempTs = System.currentTimeMillis();

		// 2.数据库操作——一次delete操作、一次insert操作
		// 删除数据库中的所有不在keepList中的信息
		// 把remoteList中所有的数据拼成一个sql，进行插入操作

		SQLiteOpenHelper openHelper = getDBProvider().getSQLiteOpenHelper();
		SQLiteDatabase database = openHelper.getWritableDatabase();
		try {
			if (keepList.size() > 0) {
				StringBuilder deleteSqlBuilder = appendChatItemInfoForDeleteSql(keepList);
				SQLiteStatement delete = database.compileStatement(deleteSqlBuilder.toString());
				long deleteCount = delete.executeUpdateDelete();
				Log.i("updateLasgMsgList", "deleteCount = " + deleteCount);
			}

			if (remoteList.size() > 0) {
				StringBuilder insertSqlBuilder = appendChatItemInfoForInsertSql(remoteList);
				SQLiteStatement insert = database.compileStatement(insertSqlBuilder.toString());
				long insertCount = insert.executeInsert();
				Log.i("updateLasgMsgList", "insertCount = " + insertCount);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		/*
		 * if (keepList.size() > 0) { String deleteSelection =
		 * getDeleteSelection(keepList); int deleteNum =
		 * getDBProvider().delete(LastMsgTable.CONTENT_URI, deleteSelection,
		 * null); Log.e("updateLasgMsgList", "deleteNum = "+deleteNum); }
		 * 
		 * if (remoteList.size() > 0) { ContentValues[] array =
		 * makeInsertValues(remoteList); Log.e("updateLasgMsgList",
		 * "2---------"+(System.currentTimeMillis()-tempTs)); tempTs =
		 * System.currentTimeMillis(); SQLiteOpenHelper openHelper =
		 * getDBProvider().getSQLiteOpenHelper(); SQLiteDatabase database =
		 * openHelper.getWritableDatabase(); database.beginTransaction(); int
		 * insertNum = getDBProvider().bulkInsert(LastMsgTable.CONTENT_URI,
		 * array); database.endTransaction(); Log.e("updateLasgMsgList",
		 * "insertCount = "+insertNum); }
		 */

		// long endTs = System.currentTimeMillis();
		// Log.e("updateLasgMsgList",
		// "3---------"+(System.currentTimeMillis()-tempTs));
		// tempTs = System.currentTimeMillis();
		// Log.e("updateLasgMsgList", "totalTime---------"+(endTs-startTs));
	}

	private static String getDeleteSelection(LinkedList<Long> keepList) {
		StringBuilder deleteBuilder = new StringBuilder();
		if (keepList.size() > 0) {
			deleteBuilder.append(LastMsgTable.C_ANOTHERID).append(" not in (");
			for (long msgId : keepList) {
				deleteBuilder.append(msgId).append(",");
			}
			deleteBuilder.setCharAt(deleteBuilder.length() - 1, ')');
		}
		return deleteBuilder.toString();
	}

	private static StringBuilder appendChatItemInfoForDeleteSql(LinkedList<Long> keepList) {
		StringBuilder deleteBuilder = new StringBuilder();
		deleteBuilder.append("delete from ").append(LastMsgTable.TABLE_NAME);
		if (keepList.size() > 0) {
			StringBuilder in = new StringBuilder();
			for (long msgId : keepList) {
				in.append(msgId).append(",");
			}
			deleteBuilder.append(" where ").append(LastMsgTable.C_ANOTHERID).append(" not in (");
			deleteBuilder.append(in);
			deleteBuilder.setCharAt(deleteBuilder.length() - 1, ')');
		}
		return deleteBuilder;
	}

	private static StringBuilder appendChatItemInfoForInsertSql(List<ChatItemInfo> list) {
		long myUid = ManagerAccount.getInstance().getCurrentId();

		StringBuilder insertBuilder = new StringBuilder();
		insertBuilder.append("INSERT INTO ").append(LastMsgTable.TABLE_NAME).append(" (");
		appendColumns2(insertBuilder, ",");
		insertBuilder.append(')').append(" VALUES ");

		long C_UNREADNUM;
		long C_ANOTHERID;
		long C_FROMID;
		long C_TIME;
		String C_CONTENT;
		String C_MEDIA_URL;
		long C_TYPE;
		long C_MSGID;
		long C_DURATION;
		long C_EXTRA_ID;
		String C_EXTRA;
		long C_USERCP;
		long C_STATUS;
		String C_ATTACH;
		long C_ISVIP;
		long C_ISNEW;
		long C_CROWNID;
		String C_NICK;
		String C_AVATAR;
		long C_RESERVED3;
		String C_RESERVED1;
		long C_HASSTARED;

		for (ChatItemInfo chatItemInfo : list) {
			C_UNREADNUM = myUid == chatItemInfo.anotherUserInfo.uid ? 0 : chatItemInfo.notReadCount;
			C_ANOTHERID = chatItemInfo.anotherUserInfo.uid;
			C_FROMID = chatItemInfo.message.sender;
			C_TIME = chatItemInfo.message.time;
			chatItemInfo.message.setEncrypted();
			C_CONTENT = getBracketString(PDEEngine.PXEncrypt(chatItemInfo.message.msgContent));
			C_MEDIA_URL = getBracketString(chatItemInfo.message.mediaUrl);
			C_TYPE = chatItemInfo.message.type;
			C_MSGID = chatItemInfo.message.msgId;
			C_DURATION = chatItemInfo.message.duration;
			C_EXTRA_ID = chatItemInfo.message.extraId;

			if (!TextUtils.isEmpty(chatItemInfo.message.extraString)) {
				C_EXTRA = getBracketString(chatItemInfo.message.extraString);
			} else if (chatItemInfo.message.extra != null) {
				C_EXTRA = getBracketString(chatItemInfo.message.extra.toString());
			} else {
				C_EXTRA = getBracketString(null);
			}
			C_USERCP = chatItemInfo.message.usercp;

			// 对方发送来的消息，直接将状态设置为发送成功
			if (chatItemInfo.message.sender != myUid) {
				C_STATUS = EgmConstants.Sending_State.SEND_SUCCESS;
			} else {
				if (chatItemInfo.message.status >= 0) {
					C_STATUS = chatItemInfo.message.status;
				} else {
					C_STATUS = EgmConstants.Sending_State.SEND_SUCCESS;
				}
			}
			C_ATTACH = getBracketString(chatItemInfo.message.attach);
			C_ISVIP = chatItemInfo.anotherUserInfo.isVip ? 1 : 0;
			C_ISNEW = chatItemInfo.anotherUserInfo.isNew ? 1 : 0;
			C_CROWNID = chatItemInfo.anotherUserInfo.crownId;
			C_NICK = getBracketString(chatItemInfo.anotherUserInfo.nick);
			C_AVATAR = getBracketString(chatItemInfo.anotherUserInfo.portraitUrl192);
			C_RESERVED3 = chatItemInfo.message.getReserved3();
			C_RESERVED1 = getBracketString("" + chatItemInfo.notReadGiftValue);
			C_HASSTARED = chatItemInfo.anotherUserInfo.hasStared ? 1 : 0;

			insertBuilder.append(" (").append(C_UNREADNUM).append(", ").append(C_ANOTHERID).append(", ")
					.append(C_FROMID).append(", ").append(C_TIME).append(", ").append(C_CONTENT).append(", ")
					.append(C_MEDIA_URL).append(", ").append(C_TYPE).append(", ").append(C_MSGID).append(", ")
					.append(C_DURATION).append(", ").append(C_EXTRA_ID).append(", ").append(C_EXTRA).append(", ")
					.append(C_USERCP).append(", ").append(C_STATUS).append(", ").append(C_ATTACH).append(", ")
					.append(C_ISVIP).append(", ").append(C_ISNEW).append(", ").append(C_CROWNID).append(", ")
					.append(C_NICK).append(", ").append(C_AVATAR).append(", ").append(C_RESERVED3).append(", ")
					.append(C_RESERVED1).append(", ").append(C_HASSTARED).append("),");
		}

		insertBuilder.deleteCharAt(insertBuilder.length() - 1);
		return insertBuilder;
	}

	private static String getBracketString(String s) {
		if (TextUtils.isEmpty(s)) {
			return "''";
		} else {
			return "'" + s + "'";
		}
	}

	private static void appendColumns2(StringBuilder builder, String split) {
		builder.append(LastMsgTable.C_UNREADNUM).append(split).append(LastMsgTable.C_ANOTHERID).append(split)
				.append(LastMsgTable.C_FROMID).append(split).append(LastMsgTable.C_TIME).append(split)
				.append(LastMsgTable.C_CONTENT).append(split).append(LastMsgTable.C_MEDIA_URL).append(split)
				.append(LastMsgTable.C_TYPE).append(split).append(LastMsgTable.C_MSGID).append(split)
				.append(LastMsgTable.C_DURATION).append(split).append(LastMsgTable.C_EXTRA_ID).append(split)
				.append(LastMsgTable.C_EXTRA).append(split).append(LastMsgTable.C_USERCP).append(split)
				.append(LastMsgTable.C_STATUS).append(split).append(LastMsgTable.C_ATTACH).append(split)
				.append(LastMsgTable.C_ISVIP).append(split).append(LastMsgTable.C_ISNEW).append(split)
				.append(LastMsgTable.C_CROWNID).append(split).append(LastMsgTable.C_NICK).append(split)
				.append(LastMsgTable.C_AVATAR).append(split).append(LastMsgTable.C_RESERVED3).append(split)
				.append(LastMsgTable.C_RESERVED1).append(split).append(LastMsgTable.C_INTERGER1);
	}

}
