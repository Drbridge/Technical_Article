package com.spiritribe.mindplus.loopback;


import com.spiritribe.mindplus.transaction.EgmBaseTransaction;
import com.spiritribe.mindplus.transaction.Transaction;
import com.spiritribe.mindplus.transaction.type.EgmServiceCode;


public class LoopBackTransaction extends Transaction {
    private LoopBack mObj = null;

    public LoopBackTransaction(LoopBack obj) {
        super(EgmBaseTransaction.TRANSACTION_UI_BROADCAST);
        this.mObj = obj;
    }

    @Override
    public void onTransact() {
        final LoopBack obj = mObj;
        notifyMessage(EgmServiceCode.TRANSACTION_SUCCESS, obj);
        mObj = null;
    }
}
