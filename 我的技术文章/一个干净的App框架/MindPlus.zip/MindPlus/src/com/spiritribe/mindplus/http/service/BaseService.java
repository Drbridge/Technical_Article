package com.spiritribe.mindplus.http.service;

import android.content.Context;

import com.spiritribe.mindplus.http.ApnReference;
import com.spiritribe.mindplus.http.ByteArrayPool;
import com.spiritribe.mindplus.http.DataChannel;
import com.spiritribe.mindplus.transaction.AsyncTransaction;
import com.spiritribe.mindplus.transaction.Transaction;
import com.spiritribe.mindplus.transaction.TransactionEngine;
import com.spiritribe.mindplus.utils.CharArrayPool;

public class BaseService {

	public static Context getServiceContext() {
		return mAppContext;
	}

	TransactionEngine mTransactionEngine;
	DataChannel mDataChanel;

	private static Context mAppContext;

	private static ByteArrayPool mArrayPool = new ByteArrayPool(1024 << 2);

	private static CharArrayPool mCharPool = new CharArrayPool(1024 << 2);

	public static void initServiceContext(Context appContext) {
		if (mAppContext == null) {
			ApnReference.getInstance(appContext);
		}
		mAppContext = appContext;

	}

	public static byte[] getByteBuf(int len) {
		return mArrayPool.getBuf(len);
	}

	public static void returnByteBuf(byte[] buf) {
		mArrayPool.returnBuf(buf);
	}

	public static char[] getCharBuf(int len) {
		return mCharPool.getBuf(len);
	}

	public static void returnCharBuf(char[] buf) {
		mCharPool.returnBuf(buf);
	}

	public BaseService(DataChannel dataChanel) {
		mDataChanel = dataChanel;
		mTransactionEngine = dataChanel.getTransactionEngine();
	}

	public int beginTransaction(Transaction trans) {
		int ret = -1;

		if (trans != null) {
			ret = trans.getId();

			if (trans instanceof AsyncTransaction) {
				((AsyncTransaction) trans).setDataChannel(mDataChanel);
			}
			if (mTransactionEngine != null) {
				mTransactionEngine.beginTransaction(trans);
			}
		}

		return ret;
	}

	public void cancelTransaction(int tid) {
		if (mTransactionEngine != null) {
			mTransactionEngine.cancelTransaction(tid);
		}
	}

}
