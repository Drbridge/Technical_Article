package com.spiritribe.mindplus.http.service;

import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicBoolean;

import com.spiritribe.mindplus.GetRecommendTransaction;
import com.spiritribe.mindplus.http.HttpDataChannel;
import com.spiritribe.mindplus.http.HttpEngine;
import com.spiritribe.mindplus.http.msg.MessageInfo;
import com.spiritribe.mindplus.http.msg.SendMsgTransaction2;
import com.spiritribe.mindplus.transaction.EgmBaseTransaction;
import com.spiritribe.mindplus.transaction.LoginTransaction;
import com.spiritribe.mindplus.transaction.Transaction;
import com.spiritribe.mindplus.transaction.TransactionEngine;
import com.spiritribe.mindplus.transaction.listener.MplusCallBack;
import com.spiritribe.mindplus.transaction.listener.GroupTransactionListener;

public class MplusService extends BaseService {
	public static final String TAG = "EgmService";

	private static MplusService mInstance = null;
	private GroupTransactionListener mGroupListener;

	/**
	 * TransactionEngine核心线程个数
	 */
	public static int CoreThreadCount = 3;

	/** 用于后台重登录时需要等待登录成功才能执行的请求缓存 */
	private AtomicBoolean mIsLoging = new AtomicBoolean(false);
	private LinkedList<Transaction> mWattingLoginList;

	public static MplusService getInstance() {
		if (mInstance == null) {
			mInstance = new MplusService();
		}
		return mInstance;
	}

	private MplusService() {
		super(new HttpDataChannel(new TransactionEngine(TransactionEngine.Priority, CoreThreadCount), new HttpEngine(3,
				Thread.NORM_PRIORITY - 1)));
		mGroupListener = new GroupTransactionListener();
		mWattingLoginList = new LinkedList<Transaction>();
	}

	public void addListener(MplusCallBack listener) {
		mGroupListener.addListener(listener);
	}

	public void removeListener(MplusCallBack listener) {
		mGroupListener.removeListener(listener);
	}

	public void addToWattingList(Transaction trans) {
		synchronized (mWattingLoginList) {
			mWattingLoginList.add(trans);
		}
	}

	public LinkedList<Transaction> getWattingList() {
		synchronized (mWattingLoginList) {
			LinkedList<Transaction> list = new LinkedList<Transaction>(mWattingLoginList);
			mWattingLoginList.clear();
			return list;
		}
	}

	@Override
	public int beginTransaction(Transaction trans) {
		trans.setListener(mGroupListener);
		return super.beginTransaction(trans);
	}

	public void setIsLoging(boolean isloging) {
		mIsLoging.set(isloging);
	}

	public boolean isLoging() {
		return mIsLoging.get();
	}

	/** 获取推荐列表 */
	public int doGetRecommend(boolean isLogin) {
		GetRecommendTransaction t = new GetRecommendTransaction(isLogin);
		beginTransaction(t);

		return t.getId();
	}

	/**
	 * 发送语音消息
	 */
	public int doSendMsg(MessageInfo info, String filePath) {
		EgmBaseTransaction t = new SendMsgTransaction2(info, filePath);
		beginTransaction(t);
		return t.getId();
	}
	
	public int doLogin(String name, String password) {
		LoginTransaction trans = new LoginTransaction(name, password);
		beginTransaction(trans);
		return trans.getId();
	}
}