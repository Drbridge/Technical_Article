package com.spiritribe.mindplus;

import com.spiritribe.mindplus.http.PlatformUtil;
import com.spiritribe.mindplus.http.THttpMethod;
import com.spiritribe.mindplus.http.THttpRequest;
import com.spiritribe.mindplus.http.service.BaseService;
import com.spiritribe.mindplus.utils.EgmProtocolConstants;
import com.spiritribe.mindplus.utils.EgmUtil;

/**
 * @author personal
 *
 */
public class MplusHttpRequest extends THttpRequest {
	
	
	public static String APP_OS_NAME = "androidPhone";
	public static final String USERAGENT = "date/" + EgmUtil.getNumberVersion(BaseService.getServiceContext()) + " ("
			+ APP_OS_NAME + "; " + android.os.Build.VERSION.RELEASE + "; " + android.os.Build.MODEL + "; "
			+ PlatformUtil.getResolution(BaseService.getServiceContext()) + "; "
			+ EgmUtil.getAppChannelID(BaseService.getServiceContext()) + ") ";

	public MplusHttpRequest(String url) {
		super(url);
		init();

	}

	public MplusHttpRequest(String url, THttpMethod type) {
		super(url, type);
		init();
	}

	public void init() {
		addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		addHeader("Accept-Encoding", "gzip, deflate");
		addHeader("PLATFORM", String.valueOf(EgmProtocolConstants.PLATFORM_ANROID));
		addHeader("APPVERSION", EgmUtil.getNumberVersion(BaseService.getServiceContext()));
		addHeader("TOKEN", "sss");
		addHeader("DEVICEID", "");
		addHeader("user-agent", USERAGENT);
		addHeader("CHANNEL", EgmUtil.getAppChannelID(BaseService.getServiceContext()));
		addHeader("PHONETYPE", android.os.Build.MODEL);
		addHeader("MEID", PlatformUtil.getDeviceID(BaseService.getServiceContext()));
	}

	public void addParametersInt(String key, int[] params) {
		for (int value : params) {
			addParameter(key, String.valueOf(value));
		}
	}

	public void addParametersLong(String key, long[] params) {
		for (long value : params) {
			addParameter(key, String.valueOf(value));
		}
	}

	public void addParametersString(String key, String[] params) {
		for (String value : params) {
			addParameter(key, value);
		}
	}

}
