package com.spiritribe.mindplus.http;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;

public class HttpCacheDBProvider extends BaseDBProvider {

	public HttpCacheDBProvider() {
		super(HttpCacheDatabase.Authority, HttpCacheDBTables.TableNames);
	}

	public HttpCacheDBProvider(Context context) {
		super(context, HttpCacheDatabase.Authority, HttpCacheDBTables.TableNames);
	}

	@Override
	protected SQLiteOpenHelper getSQLiteOpenHelper() {
		return HttpCacheDBOpenHelper.getInstance(getSQLiteContext());
	}

}
