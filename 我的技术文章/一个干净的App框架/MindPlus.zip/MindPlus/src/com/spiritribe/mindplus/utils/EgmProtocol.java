package com.spiritribe.mindplus.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import android.text.TextUtils;
import android.webkit.URLUtil;

import com.spiritribe.mindplus.MplusHttpRequest;
import com.spiritribe.mindplus.http.THttpMethod;
import com.spiritribe.mindplus.http.THttpRequest;
import com.spiritribe.mindplus.http.entity.FilePart;
import com.spiritribe.mindplus.http.entity.MultipartEntity;
import com.spiritribe.mindplus.http.entity.Part;
import com.spiritribe.mindplus.http.entity.StringPart;
import com.spiritribe.mindplus.http.msg.MessageInfo;
import com.spiritribe.mindplus.http.msg.MsgExtra;
import com.spiritribe.mindplus.http.msg.PDEEngine;

public class EgmProtocol {

	// public static String SERVER_DOMAIN =
	// EgmProtocolConstants.isDebugServer?"http://t.y.163.com/":"http://y.163.com/";

	public static String URS_DOMAIN_HTTP = "http://reg.163.com/";
	public static String URS_DOMAIN_HTTPS = "https://reg.163.com/";
	private final static String sUserAgent = "NETS_Android";

	// 反馈产品ID
	public static String FEED_PRODUCT_ID = "23001";

	private static String ZIP_LOG_FILE_NAME = "egm_android_log.zip";

	public static String PRODUCT_ID = "";
	public static String PROTOCOL_NUMBER = "1.0.0";

	private static EgmProtocol mInstance;
	// 手机登录TOKEN（采用URS提供的手机版登录方案的TOKEN）
	private String mUrsToken = null;
	// 设备ID（采用URS提供的手机版登录方案返回的ID）
	private String mUrsId = null;
	// 应用服务器生成的秘钥，密钥使用16进制的字符串表示，（跟设备对应，与用户无关，每次应用启动获取一次）
	private String encryptedKey = null;

	/************************************** API *******************************/
	/* ----------登录注册---------- */
	/** 初始化URS */
	private static final String URL_INIT_URS = URS_DOMAIN_HTTP + "services/initMobApp";
	/** 登录URS */
	private static final String URL_LOGIN_URS = URS_DOMAIN_HTTPS + "services/safeUserLoginForMob";

	/** 获取手机号验证码 */
	private static final String URL_GET_MOBILE_VERIFY_CODE = "login/getverifycode";
	/** 手机号注册 */
	private static final String URL_MOBILE_REGISTER = "login/register";
	/** 是否是同城约会1.0帐号 */
	private static final String URL_IS_YUEHUI_ACCOUNT = "login/ismember";
	/** 注册——补全用户资料 */
	private static final String URL_FILL_USER_INFO = "login/filluserinfo";
	/** 注册——绑定手机号 */
	private static final String URL_BIND_MOBILE = "login/bindmobile";
	/** 登录——上传地理位置并获取用户资料 */
	private static final String URL_LOGIN_GET_USER_INFO = "login/getmyinfo";
	/** 上传地理位置 */
	private static final String URL_UPLOAD_LOCATION = "login/uploadlocation";
	/** 退出登录 */
	private static final String URL_LOGOUT = "login/logout";
	/** 获取push所需参数 */
	private static final String URL_GET_PUSH_PARAMS = "login/getpushinfo";
	/** 获取手机绑定的通行证帐号 */
	private static final String URL_QUERY_ACCOUNT = "login/queryaccount";
	/** 读取第三方登录用户资料接口,第三方账户第一次登录后跳到注册补全资料页面时调用 */
	private static final String URL_GET_OAUTHUSERINFO = "login/getoauthuserinfo";

	/* ------------推荐----------- */
	/** 获取登录之前的推荐列表 */
	private static final String URL_GET_RECOMMEND_WITHOUT_LOGIN = "recommend/regrecommedlist";
	/** 获取推荐列表 */
	private static final String URL_GET_RECOMMEND = "recommend/getrecommendlist";
	/** 获取女性推荐列表包括悬赏 活动之类的 */
	private static final String URL_GET_RECOMMEND_FOR_FEMALE_FIRST = "recommend/getreclist";
	/** 获取碰缘分状态数据 */
	private static final String URL_GET_YUANFEN_INFO = "fate/getfateinfo";
	/** 通知服务器碰缘分开关状态 */
	private static final String URL_INFORM_YUANFEN_SWITCHER = "fate/fateswitch";
	/** 通知服务器碰缘分类型 */
	private static final String URL_INFORM_YUANFEN_TYPE = "fate/fatetypeswitch";
	/** 上传碰缘分数据 */
	private static final String URL_SEND_YUANFEN = "fate/updatefate";
	/** 获取推荐页活动列表 */
	private static final String URL_GET_COMPETITION_LIST = "activity/getlist";
	/** 获取主页排行列表 */
	private static final String URL_GET_RANK_LIST_IN_HOME = "rank/getranklist";

	/* -----------排行榜---------- */
	/** 获取排行榜 */
	private static final String URL_GET_RANK = "rank/getrankuserlist";
	/** 搜索 */
	private static final String URL_SEARCH = "search/search";
	/** 排行榜背景图 */
	private static final String URL_RANK_PICTURE = "config/getrankpic";

	/* -----------秘密花园---------- */
	/** 我的秘密花园 */
	private static final String URL_DYNAMIC_MYGARDEN = "dynamic/mygarden";
	/** 获取用户动态列表 - 下一页调用 */
	private static final String URL_DYNAMIC_GET_LIST = "dynamic/getlist";
	/** 对动态点赞 */
	private static final String URL_DYNAMIC_PRAISE = "dynamic/praise";
	/** 动态详情 */
	private static final String URL_DYNAMIC_DETAIL = "dynamic/detail";
	/** 删除动态 */
	private static final String URL_DYNAMIC_DELETE = "dynamic/delete";

	/** 获取访客的列表 */
	private static final String URL_GET_VISITORS = "dynamic/getvisitorlist";
	/** 获取赞的列表 */
	private static final String URL_GET_PRAISES = "dynamic/getpraiselist";
	/** 获取通知的列表 */
	private static final String URL_GET_NOTIFY = "dynamic/getnotices";
	/** 发布动态 */
	private static final String URL_SEND_DYNAMIC = "dynamic/add";
	/** 聚合页 */
	private static final String URL_DYNAMIC_MASHUP = "dynamic/mashup";

	/* ----------悬赏---------- */
	/** 获取女性悬赏列表 */
	private static final String URL_GET_MYAWARDFEMALE = "award/myawardfemale";
	/** 获取女性悬赏列表 */
	private static final String URL_GET_MYAWARD_MALE = "award/myawardmale";
	/** 获取女性悬赏列表 */
	private static final String URL_JOIN_AWARD = "award/join";
	/** 获取评论列表 */
	private static final String URL_GET_COMMENT_LIST = "award/getcommentlist";
	/** 提交评论 */
	private static final String URL_POST_COMMENT = "award/postcomment";
	/** 获取评论详情 */
	private static final String URL_GET_AWARD_DETAILS = "award/detail";
	/** 获取微信支付参数 */
	private static final String URL_GET_WXPAY = "/charge/wxorder";
	/** 获取女神卡片详情 */
	private static final String URL_GET_FEMALE_CARD = "chat/getskillcard";
	/** 接受女神卡片 */
	private static final String URL_POST_FEMALE_CARD = "chat/acceptskillcard";
	/** */
	private static final String URL_GET_AWARD_MALE = "award/getuserlist";
	/** 获取悬赏列表 */
	private static final String URL_GET_AWARDFELIST = "award/getlist";
	/** 获取悬赏礼物列表 */
	private static final String URL_GET_AWARD_GIFTLIST = "award/getgiftlist";
	/** 发布悬赏 */
	private static final String URL_POST_AWARD = "award/postaward";
	/** 悬赏通知列表 */
	private static final String URL_GET_AWARD_NOTICELIST = "award/noticelist";
	/** 获取技能卡礼物列表 */
	private static final String URL_GET_SKILLCARD_GIFT = "chat/getskillcardgift";
	/** 发布技能邀请卡 */
	private static final String URL_POST_SKILLCARD = "chat/postskillcard";

	/* ----------用户资料---------- */
	/** 获取用户资料 */
	private static final String URL_GET_USER_INFO = "user/getuserinfo";
	/** 获取用户资料配置项 */
	private static final String URL_GET_USER_INFO_CONFIG = "config/getuserconfig";
	/** 获取系统头像列表 */
	private static final String URL_GET_SYSPORTRAIT_LIST = "config/getsysportrait";
	/** 设置系统头像 */
	private static final String URL_UPDATE_SYSPORTRAIT_LIST = "user/updatesysportrait";
	/** 获取礼物列表 */
	private static final String URL_GET_USER_GIFT_LIST = "gift/giftlist";
	/** 获取恩客列表 */
	private static final String URL_GET_USER_ENKE_LIST = "user/getlovelist";
	/** 修改会员详细资料 */
	private static final String URL_MODIFY_USER_DETAIL_INFO = "user/updateuserinfo";
	/** 修改会员头像 */
	private static final String URL_MODIFY_USER_PROFILE = "user/updateportrait";
	/** 上传语音介绍 */
	private static final String URL_UPDATE_AUDIO_INTRODUCE = "user/uploadvoiceintroduce";
	/** 上传视频介绍 */
	private static final String URL_UPDATE_VIDEO_INTRODUCE = "user/uploadvideointroduce";
	/** 切换音频/视频 */
	private static final String URL_SWITH_AUDIO_VIDEO_MODE = "user/switchintroduce";
	/** 获取音频/视频 */
	private static final String URL_GET_AUDIO_VIDEO_MODE = "user/getintroduce";
	/** 删除语音介绍 */
	private static final String URL_DEL_AUDIO_INTRODUCE = "user/delvoiceintroduce";
	/** 获取表情配置数据 */
	private static final String URL_GET_EMOT_CONFIG = "config/getemotionconfig";
	/** 获取礼物配置数据 */
	private static final String URL_GET_GIFT_CONFIG = "config/getgiftconfig";
	/** 获取个人中心数据 */
	private static final String URL_GET_PRIVATE_DATA = "user/geteditinfo";
	/** 获取照片列表 */
	private static final String URL_GET_PICTURE_LIST = "album/getphotolist";
	/** 获取已经解锁私照列表 */
	private static final String URL_GET_UNLOCK_PICTURE_LIST = "album/getunlocklist";
	/** 获取单张私照 */
	private static final String URL_GET_SINGLE_PRI_IMAGE = "album/getphotoinfo";
	/** 赠送礼物 */
	private static final String URL_SEND_GIFT = "gift/sendgift";
	/** 赠送礼物 */
	private static final String URL_MODIFY_INTRODUCE = "user/updateintroduce";
	/** 上传照片 */
	private static final String URL_UPLOAD_PIC = "album/uploadphoto";
	/** 删除照片 */
	private static final String URL_DELETE_PIC = "album/delphoto";
	/** 赞私照 */
	private static final String URL_PRAISE_PIC = "album/praisephoto";
	/** 踩私照 */
	private static final String URL_UNLIKE_PIC = "album/step";
	/** 获取聊天列表 */
	private static final String URL_GET_CHAT_LIST = "chat/getlist";
	/** 删除聊天列表 */
	private static final String URL_DEL_CHAT_LIST = "chat/delchat";
	/** 聊天列表排序 */
	private static final String URL_SORT_CHAT_LIST = "chat/getsortlist";
	/** 删除消息 */
	private static final String URL_DEL_MSG = "chat/delmsg";
	/** 阅后即焚消息销毁接口 */
	private static final String URL_DEL_FIRE_MSG = "chat/firemsg";

	/** 获取阅后即焚消息多媒体链接接口 */
	private static final String URL_GET_FIRE_MESSAGE_MEDIA_URL = "chat/getfiremsg";
	/** 获取聊天和碰缘分文字模板 */
	private static final String URL_GET_TOPIC_DATA = "config/gettopic";
	/** 获取消息列表 */
	private static final String URL_GET_MSG_LIST = "chat/getmsglist";
	/** 举报 */
	private static final String URL_COMPLAIN = "setting/complain";
	/** 加黑 */
	private static final String URL_BLOCK = "setting/blockuser";
	/** 将消息设置为已读 */
	private static final String URL_SET_MSG_READ = "chat/setreadflag";
	/** 加星用户/取消加星用户 */
	private static final String URL_SET_STAR = "chat/setstar";
	/** 把所有消息设置成已读 */
	private static final String URL_SET_ALL_MSG_READ = "chat/setallread";
	/** 读取用户聊天技的列表 */
	private static final String URL_GET_FEMALE_BADGE_LIST = "task/badgeinfo";
	/** 读取用户聊天技的列表 */
	private static final String URL_GET_WEEK_TASK_LIST = "task/taskinfo";
	/** 读取用户聊天技的列表 */
	private static final String URL_GET_WEEK_TASK_REWARD = "task/gain";
	/** 读取用户聊天技的列表 */
	private static final String URL_GET_TALK_SKILLS_LIST = "user/getchatskills";
	/** 读取用户聊天技的列表 */
	private static final String URL_UPDATE_TALK_SKILLS_LIST = "user/updatechatskills";
	/** 获取女性账户信息 */
	private static final String URL_GET_MONEY_ACCOUNT = "user/getaccountinfo";
	/** 女性申请提现 */
	private static final String URL_APPLY_WITHDRAW = "user/withdrawapply";
	/** 验证身份证 */
	private static final String URL_AUTH_IDENTITY = "user/setwithdrawaccount";
	/** 使用Token置换登录ticket */
	private static final String URL_EXCHANGE_TICKET = URS_DOMAIN_HTTP
			+ "interfaces/mobileapp/exchangeTicketByMobToken.do";
	/** access_token置换手机登录token接口,暂时没用 */

	/** 推广封面图获取 */
	private static final String URL_COVER_AD_PIC = "login/getadpic";

	/**************************************************/

	/** 发送消息 */
	private static final String URL_SEND_MSG = "chat/sendmsg";

	EgmProtocol() {
	}

	public static EgmProtocol getInstance() {
		if (mInstance == null) {
			mInstance = new EgmProtocol();
		}
		return mInstance;
	}

	private static File getFile(String url) {
		File file = null;
		if (URLUtil.isFileUrl(url)) {
			file = new File(URI.create(url));
		} else {
			file = new File(url);
		}

		return file;
	}

	/** 获取推荐列表 */
	public THttpRequest createGetRecommendRequest(boolean isLogin) {
		MplusHttpRequest request = null;
		request = new MplusHttpRequest(getRequestUrl(URL_GET_RECOMMEND_WITHOUT_LOGIN), THttpMethod.GET);

		request.setCacheDatabase();
		request.setCacheFile();

		return request;
	}

	/**
	 * 获取完整请求URL
	 * 
	 * @param url
	 * @return
	 */
	private String getRequestUrl(String url) {
		return SERVER_DOMAIN + url;
	}

	public static String SERVER_DOMAIN = EgmProtocolConstants.isDebugServer ? "http://t.y.163.com/"
			: "http://y.163.com/";

	/**
	 * 发送消息
	 */
	public THttpRequest createSendMsg(MessageInfo msg, String filePath) {
		MplusHttpRequest request = new MplusHttpRequest(getRequestUrl(URL_SEND_MSG), THttpMethod.POST);

		Part[] parts = null;
		FilePart filePart = null;
		File file = null;
		if (!TextUtils.isEmpty(filePath)) {
			if (URLUtil.isFileUrl(filePath)) {
				file = new File(URI.create(filePath));
			} else {
				file = new File(filePath);
			}
			try {
				filePart = new FilePart("data", file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

		List<Part> list = new ArrayList<Part>();
		list.add(new StringPart("msgType", String.valueOf(msg.type)));
		list.add(new StringPart("toUserId", String.valueOf(msg.receiver)));
		list.add(new StringPart("sendType", String.valueOf(msg.sendType)));

		if (!TextUtils.isEmpty(msg.extraString)) {
			MsgExtra extra = MsgExtra.toMsgExtra(msg.extraString);
			if (extra.extraType == EgmProtocolConstants.Msg_Extra_Type.Msg_Extra_Type_Dynamic) {
				list.add(new StringPart("did", String.valueOf(extra.id)));
			}
		}

		addNotEmptyStringPart(list, "isCameraPhoto", msg.isCameraPhoto);

		if (!TextUtils.isEmpty(msg.msgContent)) {
			String content = PDEEngine.PXEncrypt(msg.msgContent);
			StringPart newPart = new StringPart("text", content);
			newPart.setCharSet("utf-8");
			list.add(newPart);
		}

		switch (msg.type) {
		case EgmProtocolConstants.MSG_TYPE.MSG_TYPE_GIFT:
			addNotEmptyStringPart(list, "giftId", msg.extraId);
			break;
		case EgmProtocolConstants.MSG_TYPE.MSG_TYPE_PRIVATE_PIC:
			addNotEmptyStringPart(list, "privacyId", msg.extraId);
			break;
		case EgmProtocolConstants.MSG_TYPE.MSG_TYPE_AUDIO:
		case EgmProtocolConstants.MSG_TYPE.MSG_TYPE_VIDEO:
			list.add(new StringPart("duration", String.valueOf(msg.duration)));
			break;
		case EgmProtocolConstants.MSG_TYPE.MSG_TYPE_FACE:
			StringPart newPart = new StringPart("faceId", msg.faceId);
			newPart.setCharSet("utf-8");
			list.add(newPart);
			break;
		}

		if (filePart != null) {
			list.add(filePart);
		}

		parts = new Part[list.size()];
		for (int i = 0; i < parts.length; i++) {
			parts[i] = list.get(i);
		}

		request.setHttpEntity(new MultipartEntity(parts));
		return request;
	}

	private static void addNotEmptyStringPart(List<Part> list, String key, long value) {
		if (value != 0) {
			list.add(new StringPart(key, String.valueOf(value)));
		}
	}

	private static void addNotEmptyStringPart(List<Part> list, String key, String value) {
		if (!TextUtils.isEmpty(value)) {
			list.add(new StringPart(key, String.valueOf(value)));
		}
	}

	private String login_urlString = "hello_test";

	public THttpRequest creatLoginRrequest(String name, String pw) {
		MplusHttpRequest request = new MplusHttpRequest(getRequestUrl(login_urlString), THttpMethod.POST);
		StringPart mPart = new StringPart("canshu1", "sdsdf");
		Part[] mParts = new Part[1];
		mParts[0] = mPart;
		request.setHttpEntity(new MultipartEntity(mParts));
		return request;
	}
}
