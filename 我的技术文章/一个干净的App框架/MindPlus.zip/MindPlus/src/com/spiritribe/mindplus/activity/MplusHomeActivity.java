package com.spiritribe.mindplus.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.spiritribe.mindplus.R;
import com.spiritribe.mindplus.RecommendListInfo;
import com.spiritribe.mindplus.adapter.HomePagerAdapter;
import com.spiritribe.mindplus.http.service.MplusService;
import com.spiritribe.mindplus.slidingmenu.lib.SlidingMenu;
import com.spiritribe.mindplus.transaction.listener.MplusCallBack;
import com.spiritribe.mindplus.utils.ToastUtils;
import com.spiritribe.mindplus.view.DrawerView;
import com.spiritribe.mindplus.view.TableSelectView;
import com.spiritribe.mindplus.view.TableSelectView.OnTableSelectListener;

public class MplusHomeActivity extends MplusBaseAcvitiy {

	private ViewPager mViewPager;
	private TableSelectView mSelectView;

	private TextView mLeftView;
	protected SlidingMenu side_drawer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mplus);
		getActionBar().hide();
		HttpTestActivity.startActivity(this);
		MplusService.getInstance().addListener(mCallBack);
		initView();

	}

	private void initView() {

		mLeftView = (TextView) findViewById(R.id.left);
		side_drawer = new DrawerView(this).initSlidingMenu();
		mViewPager = (ViewPager) findViewById(R.id.viewpager);
		mViewPager.setAdapter(new HomePagerAdapter(getSupportFragmentManager()));
		mViewPager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				mSelectView.setSelectItem(arg0);
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}
		});
		mSelectView = (TableSelectView) findViewById(R.id.select_container);
		mSelectView.setOnTableSelectListener(new OnTableSelectListener() {

			@Override
			public void onSelect(int index) {
				mViewPager.setCurrentItem(index);

			}

			@Override
			public void onReSelcet() {

			}
		});

		mLeftView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				ToastUtils.showToast(MplusHomeActivity.this, "左边按钮点击");
				if (side_drawer.isMenuShowing()) {
					side_drawer.showContent();
				} else {
					side_drawer.showMenu();

				}
			}
		});
	}

	private MplusCallBack mCallBack = new MplusCallBack() {
		public void onGetRecSucess(int tid, int code, RecommendListInfo obj) {
			Log.v("lishang", "多界面刷新");
		};
	};

}
