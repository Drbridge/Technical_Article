package com.spiritribe.mindplus.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

/**
 * @author 可以控制是否可以滑动
 * 
 */
public class SlideOffViewPager extends ViewPager {

	private boolean isCanScroll;

	public SlideOffViewPager(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public SlideOffViewPager(Context context) {
		super(context);
		init();
	}

	private void init() {
		isCanScroll = true;
	}

	public void setScanScroll(boolean isCanScroll) {
		this.isCanScroll = isCanScroll;
	}

	@Override
	public boolean onTouchEvent(MotionEvent arg0) {
		if (!isCanScroll) {
			return false;
		} else {
			return super.onTouchEvent(arg0);
		}
	}
}
