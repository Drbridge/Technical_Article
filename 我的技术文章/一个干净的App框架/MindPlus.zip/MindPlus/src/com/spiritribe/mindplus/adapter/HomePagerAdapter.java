package com.spiritribe.mindplus.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.spiritribe.mindplus.fragment.FragmentAssistance;
import com.spiritribe.mindplus.fragment.FragmentBase;
import com.spiritribe.mindplus.fragment.FragmentQuestion;
import com.spiritribe.mindplus.fragment.FragmentSquare;

public class HomePagerAdapter extends FragmentPagerAdapter {

	/**
	 * Fragment 数目
	 */
	private static final int TAB_COUNT = 3;

	public interface IHomeIndex {
		int QUESTION = 0;
		int ANSWERS = 1;
		int SQUARE = 2;
	}

	public HomePagerAdapter(FragmentManager fm) {
		super(fm);
	}

	@Override
	public Fragment getItem(int index) {
		FragmentBase fragment = null;
		switch (index) {
		case IHomeIndex.QUESTION:
			fragment = FragmentQuestion.newInstance("11111111111");
			break;
		case IHomeIndex.ANSWERS:
			fragment = FragmentAssistance.newInstance("22222222222");
			break;
		case IHomeIndex.SQUARE:
			fragment = FragmentSquare.newInstance("333333333");
			break;
		default:
			break;
		}
		return fragment;
	}

	@Override
	public int getCount() {
		return TAB_COUNT;
	}

}
