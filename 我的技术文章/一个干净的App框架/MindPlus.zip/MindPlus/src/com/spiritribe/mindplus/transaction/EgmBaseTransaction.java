package com.spiritribe.mindplus.transaction;

import java.lang.reflect.Type;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import com.spiritribe.mindplus.http.HttpCache;
import com.spiritribe.mindplus.http.HttpCacheManager;
import com.spiritribe.mindplus.http.THttpRequest;
import com.spiritribe.mindplus.transaction.type.EgmServiceCode;
import com.spiritribe.mindplus.transaction.type.TransTypeCode;

/**
 * 定义各协议transaction的id，进行一些返回数据外层的解析及通用错误的处理
 * 
 * @author echo_chen
 * @since 2014-03-17
 */

public abstract class EgmBaseTransaction extends StringAsyncTransaction {

	private boolean TestData = false;
	private String TestFileName = null;

	private Object mRequest;
	/** 标志该协议请求是否需要登录过才能执行，是的话在有未完成登录前需要加入等待执行队列 */
	private boolean mNeedLogin = false;
	private EgmBaseTransaction mCurrentTx;

	public EgmBaseTransaction(int type) {
		super(type);
		mCurrentTx = this;
	}

	public void setNeedLogin(boolean needlogin) {
		if (mNeedLogin != needlogin) {
			mNeedLogin = needlogin;
		}
	}

	public boolean isNeedLogin() {
		return mNeedLogin;
	}

	/**
	 * 用于界面内部传递数据
	 */
	public static final int TRANSACTION_UI_BROADCAST = 1;

	// Transaction类型从100开始，前面保留，注意定义自己的字段，一般200为分割线
	private static final int TRANSACTION_TYPE_LS_BASE = 0x100;
	public static final int TRANSACTION_TYPE_GET_RECOMMEND = TRANSACTION_TYPE_LS_BASE + 1;
	public static final int TRANSACTION_DOWNLOAD_MSG_RES = TRANSACTION_TYPE_LS_BASE + 2;
	public static final int TRANSACTION_SEND_MSG = TRANSACTION_TYPE_LS_BASE + 3;
	public static final int TRANSACTION_LOGIN = TRANSACTION_TYPE_LS_BASE + 4;
	protected class XoneNotifyTransaction extends NotifyTransaction {

		public XoneNotifyTransaction(AsyncTransaction tran, Object data, int type, int code) {
			super(tran, data, type, code);
		}

		public XoneNotifyTransaction(List<AsyncTransaction> trans, Object data, int type, int code) {
			super(trans, data, type, code);
		}

		@Override
		public void doBeforeTransact() {
			if (isSuccessNotify()) {
				Object data = getData();
				if (data != null) {
					try {
						do {
							BaseData base = null;
							Type type = new TypeToken<BaseData>() {
							}.getType();
							if (data instanceof String) {
								base = gson.fromJson((String) data, type);
							} else if (data instanceof HttpCache) {
								String str = readString(null, ((HttpCache) data).LocalFile.openInputStream(),
										((HttpCache) data).Charset);
								base = gson.fromJson(str, type);
							} else {
								setNotifyTypeAndCode(NOTIFY_TYPE_ERROR, 0);
								break;
							}

							int code = base.code;
							if (code == EgmServiceCode.PROTOCOL_CODE_SUCCESS) {
								resetData(base.data);
							}
							// 特殊处理，易信加好友，未注册，需要返回数据
							// 因关键词过滤导致消息发送失败，需要返回内容
							else if (code == EgmServiceCode.TRANSACTION_YIXIN_NO_REGISTER
									|| code == EgmServiceCode.TRANSACTION_CHAT_KEYWORDS_BLOCKED) {
								resetData(base.data);
								setNotifyTypeAndCode(NOTIFY_TYPE_SUCCESS, code);
							} else {
								resetData(base);
								setNotifyTypeAndCode(NOTIFY_TYPE_ERROR, code);
							}

						} while (false);
					} catch (Exception e) {
						e.printStackTrace();
						if (mRequest != null && mRequest instanceof THttpRequest) {
							THttpRequest httpRequest = (THttpRequest) mRequest;
							HttpCacheManager.deleteHttpCache(httpRequest);
						}

						setNotifyTypeAndCode(NOTIFY_TYPE_ERROR, TransTypeCode.ERR_CODE_DATA_PARSE_EXCEPTION);
					}
				} else {
					setNotifyTypeAndCode(NOTIFY_TYPE_ERROR, 0);
				}
			}
		}

	}

	private static class JsonElementJsonDeserializer implements JsonDeserializer<JsonElement> {
		@Override
		public JsonElement deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
				throws JsonParseException {
			return json;
		}
	}

	private final static Gson gson = new GsonBuilder().registerTypeAdapter(JsonElement.class,
			new JsonElementJsonDeserializer()).create();

	@Override
	public NotifyTransaction createNotifyTransaction(Object data, int notifyType, int code) {
		return new XoneNotifyTransaction(this, data, notifyType, code);
	}

	@Override
	public NotifyTransaction createNotifyTransaction(List<AsyncTransaction> trans, Object data, int notifyType, int code) {
		return new XoneNotifyTransaction(trans, data, notifyType, code);
	}

	protected void setTestFileName(String name) {
		TestData = true;
		TestFileName = name;
	}

	@Override
	protected void sendRequest(Object obj) {
		mRequest = obj;
		super.sendRequest(obj);
	}

	@Override
	protected void sendRequest(Object obj, AsyncTransaction trans) {
		mRequest = obj;
		super.sendRequest(obj, trans);
	}

	@Override
	protected final void onTransactionSuccess(int code, Object obj) {
		onEgmTransactionSuccess(code, obj);
	}

	@Override
	protected final void onTransactionError(int errCode, Object obj) {
		if (obj != null && obj instanceof BaseData) {
			BaseData data = (BaseData) obj;
			if (!onEgmTransactionError(errCode, data)) {
				onEgmTransactionError(errCode, data.message);
			}
		} else {
			onEgmTransactionError(errCode, obj);
		}
	}

	protected void onEgmTransactionSuccess(int code, Object obj) {

	}

	/**
	 * 
	 * @param errCode
	 * @param data
	 * @return true 表示已处理，不再执行onEgmTransactionError(int errCode, Object obj)
	 */
	protected boolean onEgmTransactionError(int errCode, BaseData data) {
		return false;
	}

	protected void onEgmTransactionError(int errCode, Object obj) {
		notifyError(errCode, obj);
	}

	/** 通知数据解析错误 */
	protected void notifyDataParseError() {
		notifyError(EgmServiceCode.ERR_CODE_DATA_PARSE_EXCEPTION, "李尚 测试");
	}
}
