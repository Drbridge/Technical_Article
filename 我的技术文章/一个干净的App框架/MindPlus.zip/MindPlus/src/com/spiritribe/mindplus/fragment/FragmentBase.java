package com.spiritribe.mindplus.fragment;

import android.support.v4.app.Fragment;

public class FragmentBase extends Fragment {

	public FragmentBase() {
		// TODO Auto-generated constructor stub
	}

}
