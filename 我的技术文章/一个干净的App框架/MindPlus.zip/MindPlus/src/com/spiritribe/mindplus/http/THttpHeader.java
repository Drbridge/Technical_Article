package com.spiritribe.mindplus.http;


public class THttpHeader extends KeyValuePair {

	public THttpHeader(String key, String value) {
		super(key, value);
	}
}
