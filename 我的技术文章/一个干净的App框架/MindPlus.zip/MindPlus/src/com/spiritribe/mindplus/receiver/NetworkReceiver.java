package com.spiritribe.mindplus.receiver;

import com.spiritribe.mindplus.http.PlatformUtil;
import com.spiritribe.mindplus.utils.ToastUtil;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class NetworkReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		PlatformUtil.updateCurrentNetworkInfo(context);
		refreshWhenReconnect(context);
		ToastUtil.showToast(context, "重新开启");
		Log.v("lishang", "ddd");
	}

	// 填充需要刷新的事件
	private void refreshWhenReconnect(Context context) {

		// 刷新个人中心
		if (PlatformUtil.hasConnected(context)) {

		}

	}
}
