package com.spiritribe.mindplus.app;

import com.spiritribe.mindplus.http.service.BaseService;
import com.spiritribe.mindplus.http.service.MplusService;

import android.app.Application;

public class MindPlusApplication extends Application {

	private static Application mApplicatioContext;

	public MindPlusApplication() {
		super();
	}

	@Override
	public void onCreate() {
		super.onCreate();
		mApplicatioContext = this;
		initConfig();
	}

	// initial application
	private void initConfig() {
		BaseService.initServiceContext(this);
		MplusService.getInstance();
	}

	public static Application getAppInstance() {
		if (mApplicatioContext == null)
			throw new NullPointerException("Appliaction not create or be terminated!");
		return mApplicatioContext;
	}
}
