package com.spiritribe.mindplus.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.spiritribe.mindplus.R;

public class FragmentSquare extends FragmentBase {
	
	private FragmentActivity mActivity;

	public static FragmentBase newInstance(String tag) {
		FragmentSquare mFragment = new FragmentSquare();
		Bundle bundle = new Bundle();
		bundle.putString("title", tag);
		mFragment.setArguments(bundle);
		return mFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		mActivity = getActivity();
		View rootView = inflater.inflate(R.layout.fragment_question, null);
		TextView view = (TextView) rootView.findViewById(R.id.tips);
		view.setText(view.getText() + (String) getArguments().get("title"));
		return rootView;
	}
}
