package com.spiritribe.mindplus.view;

import android.R.integer;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

public class TableSelectView extends LinearLayout {

	private int mCurrentIndex;
	private OnTableSelectListener mOnTableSelect;

	public TableSelectView(Context context) {
		super(context);
		init();
	}

	public TableSelectView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public TableSelectView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	private void init() {
		mCurrentIndex = 0;
	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();
		int count = getChildCount();
		for (int i = 0; i < count; i++) {
			View view = getChildAt(i);
			view.setTag(new Integer(i));
			view.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (mOnTableSelect != null) {
						mCurrentIndex = (Integer) v.getTag();
						mOnTableSelect.onSelect(mCurrentIndex);
						setSelectItem(mCurrentIndex);
					}
				}
			});
		}
		setSelectItem(mCurrentIndex);
	}

	public void setOnTableSelectListener(OnTableSelectListener listener) {
		mOnTableSelect = listener;
	}

	public interface OnTableSelectListener {
		void onSelect(int index);

		void onReSelcet();
	}

	public void setSelectItem(int index) {
		int count = getChildCount();
		for (int i = 0; i < count; i++) {
			int value = ((Integer) getChildAt(i).getTag()).intValue();
			if (index != value) {
				getChildAt(i).setSelected(false);
			} else {
				getChildAt(i).setSelected(true);
			}
		}
	}
}
