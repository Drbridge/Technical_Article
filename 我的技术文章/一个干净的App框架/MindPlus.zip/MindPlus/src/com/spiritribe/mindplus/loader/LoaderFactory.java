package com.spiritribe.mindplus.loader;

import android.content.Context;

/**
 * Loader工厂类
 */
public class LoaderFactory {
	
	public static final int CHAT_LIST_SORT_TIME = 0 ;
	public static final int CHAT_LIST_SORT_RICH = 1 ;
	public static final int CHAT_LIST_SORT_INIT = 2 ;
	
	public static int CHAT_LIST_CHOOSE_ALL = 0;
	public static int CHAT_LIST_CHOOSE_NEW = 1;
	public static int CHAT_LIST_CHOOSE_STAR = 2;
	
	public static Loader getLoader(Context context, int loaderType, int chooseType) {
		boolean onlyNew = false;
		switch (loaderType) {
		case CHAT_LIST_SORT_TIME:
			return new LastMsgTimeLoader(context, chooseType);
		case CHAT_LIST_SORT_RICH:
			return new LastMsgRichLoader(context, chooseType);
		case CHAT_LIST_SORT_INIT:
			return new LastMsgInitLoader(context, chooseType);
		default:
			return null;
		}
	}
}
