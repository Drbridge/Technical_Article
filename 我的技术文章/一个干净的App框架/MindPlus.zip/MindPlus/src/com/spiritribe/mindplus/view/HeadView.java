package com.spiritribe.mindplus.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.spiritribe.mindplus.R;
import com.spiritribe.mindplus.http.image.ImageViewAsyncCallback;
import com.spiritribe.mindplus.utils.EgmUtil;

public class HeadView extends RelativeLayout {

	private CircleImageView mHeadView;

	private int mType;
	private int mProfileSize;
	// 32*32
	public static final int PROFILE_SIZE_MICRO = 0;
	// 48*48
	public static final int PROFILE_SIZE_TINY = 1;
	// 64*64
	public static final int PROFILE_SIZE_SMALL = 2;
	// 96*96
	public static final int PROFILE_SIZE_BIG = 3;
	// 102*102
	public static final int PROFILE_SIZE_LARGE = 4;

	private boolean isXiaoAi = false;

	public HeadView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public HeadView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public HeadView(Context context) {
		super(context);
	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();
		initViews();
	}

	public boolean isXiaoAi() {
		return isXiaoAi;
	}

	public void setXiaoAi(boolean isXiaoAi) {
		this.isXiaoAi = isXiaoAi;
	}

	public void initViews() {
		if (mHeadView == null) {
			mHeadView = new CircleImageView(getContext());
			LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
			lp.addRule(RelativeLayout.CENTER_IN_PARENT);
			this.addView(mHeadView, lp);
			mHeadView.setImageResource(R.drawable.bg_portrait_man_default_200);
		}
	}

	public void setImageUrl(boolean isVip, int profileType, String url, int sex) {
		setImage(isVip, profileType, url, sex, 0, 0, 0, null);
	}

	public void setImageUrl(boolean isVip, int profileType, String url, int sex, int borderColor) {
		setImage(isVip, profileType, url, sex, 0, 0, borderColor, null);
	}

	public void setImageUrl(boolean isVip, int profileType, String url, int sex, int borderId, int borderPx) {
		setImage(isVip, profileType, url, sex, borderId, borderPx, 0, null);
	}

	public void setImageUrlWithNoBorder(boolean isVip, int profileType, String url, int sex) {
		setImage(isVip, profileType, url, sex, -1, 0, 0, null);
	}

	public void setImageBitmap(boolean isVip, int profileType, int sex, int borderId, int borderPx, Bitmap bitmap) {
		setImage(isVip, profileType, null, sex, borderId, borderPx, 0, bitmap);
	}

	public void setImage(boolean isVip, int profileType, String url, int sex, int borderId, int borderPx,
			int borderColor, Bitmap bitmap) {
		mType = profileType;
		mProfileSize = getProfileSizeByType(profileType);
		ViewGroup.LayoutParams lp = this.getLayoutParams();
		mProfileSize = EgmUtil.dip2px(getContext(), mProfileSize);
		lp.width = mProfileSize;
		lp.height = mProfileSize;
		this.setLayoutParams(lp);
		// border
		if (profileType != PROFILE_SIZE_TINY && profileType != PROFILE_SIZE_MICRO) { // TINY头像不加边框
			if (borderId == -1) {
				// -1表示不添加border
			} else if (borderId > 0) {
				this.setBackgroundResource(borderId);
				mProfileSize -= borderPx;
				// mHeadView.setBorderColor(Color.argb(0x66, 0xff, 0xff, 0xff));
				mHeadView.setBorderWidth(0);
			} else {
				if (borderColor > 0) {
					mHeadView.setBorderColor(borderColor);
				} else {
					mHeadView.setBorderColor(getContext().getResources().getColor(R.color.head_border));
				}
				mHeadView.setBorderWidth(EgmUtil.dip2px(getContext(), 2));
				this.setBackgroundResource(0);
			}
		}
		lp = mHeadView.getLayoutParams();
		lp.width = mProfileSize;
		lp.height = mProfileSize;

		mHeadView.setLayoutParams(lp);
		// 默认头像
		mHeadView.setImageResource(R.drawable.bg_portrait_man_default_200);

		if (bitmap != null) {
			mHeadView.setTag(null);
			mHeadView.setImageBitmap(bitmap);
		} else {
			if (TextUtils.isEmpty(url)) {
				mHeadView.setTag(null);
			} else {
				mHeadView.setTag(new ImageViewAsyncCallback(mHeadView, url));
			}
		}

	}

	public void setImage(boolean isVip, int profileSize, Bitmap bitmap) {
		mHeadView.setImageBitmap(bitmap);
	}

	public static int getProfileSizeByType(int type) {
		switch (type) {
		case PROFILE_SIZE_MICRO:
			return 32;
		case PROFILE_SIZE_TINY:
			return 48;
		case PROFILE_SIZE_SMALL:
			return 64;
		case PROFILE_SIZE_BIG:
			return 96;
		case PROFILE_SIZE_LARGE:
			return 102;
		}
		return 102;
	}

	/**
	 * 设置HeadView头像照片，不包含Level
	 * 
	 * @param profileType
	 * @param url
	 * @param sex
	 * @param borderWidth
	 * @param borderResId
	 * @param borderColor
	 */
	public void setSimplePortrait(int profileType, String url, int sex, int borderWidth, int borderResId,
			int borderColor) {
		mProfileSize = getProfileSizeByType(profileType);
		ViewGroup.LayoutParams lp = this.getLayoutParams();
		mProfileSize = EgmUtil.dip2px(getContext(), mProfileSize);
		lp.width = mProfileSize;
		lp.height = mProfileSize;
		this.setLayoutParams(lp);
		// border
		if (borderResId != -1) {
			this.setBackgroundResource(borderResId);
			mProfileSize -= borderWidth * 2;
			mHeadView.setBorderWidth(0);
		} else {
			mHeadView.setBorderColor(borderColor == -1 ? getContext().getResources().getColor(R.color.head_border)
					: borderColor);
			mHeadView.setBorderWidth(borderWidth);
			this.setBackgroundResource(0);
		}
		lp = mHeadView.getLayoutParams();
		lp.width = mProfileSize;
		lp.height = mProfileSize;
		mHeadView.setLayoutParams(lp);

		mHeadView.setImageResource(R.drawable.bg_portrait_man_default_200);

	}
}
