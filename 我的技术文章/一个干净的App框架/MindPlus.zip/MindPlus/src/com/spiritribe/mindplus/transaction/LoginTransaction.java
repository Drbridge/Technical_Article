package com.spiritribe.mindplus.transaction;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.spiritribe.mindplus.http.THttpRequest;
import com.spiritribe.mindplus.http.msg.SendMsgResult;
import com.spiritribe.mindplus.transaction.type.EgmServiceCode;
import com.spiritribe.mindplus.utils.EgmProtocol;

public class LoginTransaction extends EgmBaseTransaction {

	private String mName;
	private String mPassword;

	public LoginTransaction(String name, String password) {
		super(TRANSACTION_LOGIN);
		mName = name;
		mPassword = password;
	}

	@Override
	public void onTransact() {

		THttpRequest request = EgmProtocol.getInstance().creatLoginRrequest(mName, mPassword);
		sendRequest(request);
	}

	@Override
	protected void onEgmTransactionSuccess(int code, Object obj) {
		SendMsgResult result = null;
		if (obj != null && obj instanceof JsonElement) {
			Gson gson = new Gson();
			JsonElement json = (JsonElement) obj;
			result = gson.fromJson(json, SendMsgResult.class);
		}

		if (result == null) {
			return;
		}

		notifyMessage(EgmServiceCode.TRANSACTION_SUCCESS, result);
	}

	@Override
	protected void onEgmTransactionError(int errCode, Object obj) {
		super.onEgmTransactionError(errCode, obj);
	}

}
