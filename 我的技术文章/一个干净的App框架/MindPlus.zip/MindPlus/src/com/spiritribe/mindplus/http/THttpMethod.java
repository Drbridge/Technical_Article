package com.spiritribe.mindplus.http;

public enum THttpMethod {
	GET, POST, PUT, DELETE, HEAD, OPTIONS
}


