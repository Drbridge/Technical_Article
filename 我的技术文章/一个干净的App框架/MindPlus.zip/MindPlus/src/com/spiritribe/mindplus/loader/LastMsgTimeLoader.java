package com.spiritribe.mindplus.loader;

import android.content.Context;
import android.database.Cursor;

import com.spiritribe.mindplus.http.msg.LastMsgDBManager;

/**
 * 时间排序loader
 */
public class LastMsgTimeLoader extends Loader{
	
	private int chooseType ;

	public LastMsgTimeLoader(Context context) {
		super(context);
	}
	
	public LastMsgTimeLoader(Context context , int chooseType){
		this(context);
		this.chooseType = chooseType ;
	}

	@Override
	public Cursor getCursor() {
		Cursor cursor = LastMsgDBManager.getLastMsgList(chooseType);
		return cursor;
	}
}
