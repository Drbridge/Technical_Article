package com.spiritribe.mindplus.transaction;

import com.spiritribe.mindplus.http.CacheManager;
import com.spiritribe.mindplus.transaction.type.TransTypeCode;

public class ClearCacheTask extends Transaction {

	public ClearCacheTask() {
		super(TransTypeCode.TYPE_CLEAR_CACHE);
	}

	@Override
	public void onTransact() {
		CacheManager.deleteCacheSync();
	}

}