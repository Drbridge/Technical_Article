package com.spiritribe.mindplus.http.file;

import java.util.ArrayList;

import com.spiritribe.mindplus.http.StoreFile;

public class FileResult {

	public String mUrl;
	public ArrayList<FileDownloadListener> mCallback = new ArrayList<FileDownloadListener>();
	public StoreFile mStoreFile;
	public String mError;
	public int errCode;
	
	public FileResult() {
		
	}
	
	public FileResult(FileResult result) {
		mUrl = result.mUrl;
		mCallback = result.mCallback;
		mStoreFile = result.mStoreFile;
		mError = result.mError;
		errCode = result.errCode;
	}
	
}
