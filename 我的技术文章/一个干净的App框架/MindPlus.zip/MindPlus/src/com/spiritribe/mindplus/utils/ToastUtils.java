package com.spiritribe.mindplus.utils;

import android.content.Context;
import android.widget.Toast;

public class ToastUtils {

	public static void showToast(Context context, int resID) {
		Toast.makeText(context, resID, Toast.LENGTH_SHORT).show();
	}

	public static void showToast(Context context, String content) {
		Toast.makeText(context, content, Toast.LENGTH_SHORT).show();
	}
}
