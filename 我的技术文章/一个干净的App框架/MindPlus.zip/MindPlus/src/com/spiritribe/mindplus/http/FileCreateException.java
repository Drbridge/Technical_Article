package com.spiritribe.mindplus.http;

import java.io.IOException;

public class FileCreateException extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 226859461189549805L;

}
