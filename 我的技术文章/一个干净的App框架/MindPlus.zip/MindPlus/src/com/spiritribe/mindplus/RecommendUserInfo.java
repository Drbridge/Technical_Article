package com.spiritribe.mindplus;

import com.spiritribe.mindplus.utils.EgmProtocolConstants;

public class RecommendUserInfo {
	private static final boolean DEBUG = EgmProtocolConstants.RANDOM_DEBUG_DATA;

	public long uid;// 用户ID
	public int sex;// 性别 0:女 1:男
	public int age;// 年龄
	public int height;// 身高
	public int bust;// 三围-胸围(女)
	public int waist;// 三围-腰围(女)
	public int hip;// 三围-臀围(女)
	public int cup;// 三围-罩杯(女)
	/** 当前等级 */
	public int level;
	/** 等级对应封号 */
	public String levelName;
	/** 当前魅力值（豪气值），不会减少 */
	public long usercp;
	public String nick;// 用户昵称
	public boolean isVip;// 是否vip
	public String portraitUrl;// 用户头像原图url
	public String portraitUrl192;// 用户192x192头像裁剪图url
	public String portraitUrl640;// 用户640x480头像裁剪图url
	public String portraitUrl316;// 用户316x237头像裁剪图url
	public long visitTimes;// 访问人气(女)
	public long privatePhotoCount;// 私照数(女)
	public int status;// 用户状态：0 正常 1冻结
	public boolean isNew;// 是否新用户
	public String alg; // 推荐算法统计字段
	public boolean hasVideoIntro;

}
