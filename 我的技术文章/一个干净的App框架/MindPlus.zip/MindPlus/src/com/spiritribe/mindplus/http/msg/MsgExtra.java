package com.spiritribe.mindplus.http.msg;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.Gson;

/**
 * 聊天扩展内容
 */
public class MsgExtra implements Parcelable{
	
	public int sysMsgType ;//系统消息类型
	public String title ;//活动标题
	public String url ;//活动url
	public String button1;//按钮1描述
	public String button2;//按钮2描述

	// 1.10版本新增加字段
	public int extraType;//消息扩展类型
	public int subType;//扩展信息子类型，根据extraType再细分，如果是动态类型则为：DynamicType
	public String text;//扩展文字描述
	public String mediaUrl;//扩展信息媒体url
	public long id;//扩展信息id，如动态类型则对应动态id
	
	// 1.12版本新增加字段
	public int skillId;//技能邀请卡技能id
	public String skillName;//技能邀请卡技能名称
	public int giftId;//技能邀请卡礼物id
	public int skillcardstatus;//卡片状态 0 对方未响应  1 对方接受  2 对方拒绝  3 卡片过期
	public String msgTips;//聊天列表提示语
	
	public String upgradeVer;//版本信息
	
	// 1.13版本新增加字段
	public int count;//未读悬赏通知数量
	
	public static MsgExtra toMsgExtra(String json){
		MsgExtra extra = null ;
		Gson gson = new Gson();
		extra = gson.fromJson(json,MsgExtra.class);
		return extra ;
	}
	public MsgExtra(){
	    
	}
	private MsgExtra(Parcel in){
	    sysMsgType = in.readInt();
	    title = in.readString();
	    url = in.readString();
	    button1 = in.readString();
	    button2 = in.readString();
	    
	    extraType = in.readInt();
	    subType = in.readInt();
	    text = in.readString();
	    mediaUrl = in.readString();
	    id = in.readLong();
	    
	    skillId = in.readInt();
	    skillName = in.readString();
	    giftId = in.readInt();
	    skillcardstatus = in.readInt();
    }
	
	public static final Parcelable.Creator<MsgExtra> CREATOR = new Parcelable.Creator<MsgExtra>() {
        @Override
        public MsgExtra createFromParcel(Parcel in) {
            return new MsgExtra(in);
        }
        @Override
        public MsgExtra[] newArray(int size) {
            return new MsgExtra[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(sysMsgType);
        dest.writeString(title);
        dest.writeString(url);
        dest.writeString(button1);
        dest.writeString(button2);
        
        dest.writeInt(extraType);
        dest.writeInt(subType);
        dest.writeString(text);
        dest.writeString(mediaUrl);
        dest.writeLong(id);
        
        dest.writeInt(skillId);
        dest.writeString(skillName);
        dest.writeInt(giftId);
        dest.writeInt(skillcardstatus);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
