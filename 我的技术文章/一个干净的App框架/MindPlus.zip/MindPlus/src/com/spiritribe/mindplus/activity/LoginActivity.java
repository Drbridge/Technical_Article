package com.spiritribe.mindplus.activity;

import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.sina.weibo.sdk.auth.Oauth2AccessToken;
import com.sina.weibo.sdk.auth.WeiboAuth;
import com.sina.weibo.sdk.auth.WeiboAuthListener;
import com.sina.weibo.sdk.auth.sso.SsoHandler;
import com.sina.weibo.sdk.exception.WeiboException;
import com.spiritribe.mindplus.R;
import com.spiritribe.mindplus.utils.ToastUtil;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.SendAuth;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;

public class LoginActivity extends MplusBaseAcvitiy implements OnClickListener {

	private Activity mActivity;

	public static void startActivity(Context context) {

		Intent intent = new Intent(context, LoginActivity.class);
		if (!(context instanceof Activity)) {
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		}
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		mActivity = this;
		initView();
	}

	private void initView() {

		View item = findViewById(R.id.btn_weixin);
		item.setOnClickListener(this);
		item = findViewById(R.id.btn_weibo);
		item.setOnClickListener(this);
		item = findViewById(R.id.btn_qq);
		item.setOnClickListener(this);
	}

	private int mLoginType;

	interface ILoginType {
		int WXIN = 0;
		int WEIBO = 1;
		int QQ = 2;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_weixin:
			mLoginType = ILoginType.WXIN;
			loginWithWXinSDK(mActivity);
			break;
		case R.id.btn_weibo:
			mLoginType = ILoginType.WEIBO;
			loginWithWeiboSDK();
			break;
		case R.id.btn_qq:
			mLoginType = ILoginType.QQ;
			loginWithQQSDK();
			break;
		default:
			break;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		// 只有QQ、微博有回调，选性别不回调，微信不回调
		switch (mLoginType) {
		case ILoginType.QQ:
			mTencent.onActivityResult(requestCode, resultCode, data);
			break;
		case ILoginType.WEIBO:
			if (mSsoHandler != null) {
				mSsoHandler.authorizeCallBack(requestCode, resultCode, data);
			}
			break;
		default:
			break;
		}
	}

	private static final String WEIXIN_APP_ID = "wxb326c9b1691d5dfc";

	/**
	 * @param 微信SDK登录入口
	 *            获取code实际是token，但不是AccessToken
	 */
	public void loginWithWXinSDK(Context context) {

		IWXAPI iwxapi = WXAPIFactory.createWXAPI(mActivity, WEIXIN_APP_ID, true);
		try {
			boolean ret = iwxapi.registerApp(WEIXIN_APP_ID);
			if (ret) {
				SendAuth.Req req = new SendAuth.Req();
				req.scope = "snsapi_userinfo";
				req.state = "wechat_sdk_demo_test";
				iwxapi.sendReq(req);
			} else {
				ToastUtil.showToast(mActivity, R.string.app_id_illegal);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * QQSDK登陆入口
	 */
	private Tencent mTencent;
	private final String QQ_LOGIN_APP_ID = "1102305277";

	private void loginWithQQSDK() {
		mTencent = Tencent.createInstance(QQ_LOGIN_APP_ID, mActivity.getApplicationContext());
		// if (!mTencent.isSessionValid())
		// 每次点击都重新登录
		BaseUiListener baseUiListener = new BaseUiListener() {

			@Override
			protected void doComplete(JSONObject obj) {
				if (null == obj)
					return;

				String accessToken = (String) obj.opt("access_token");
				// if (!TextUtils.isEmpty(accessToken)) {
				// mQQTokenInfo = accessToken;
				// String ursId = EgmPrefHelper.getURSId(mActivity);
				// if (TextUtils.isEmpty(ursId)) { // 还未初始化URS
				// EgmService.getInstance().doInitURS();
				// } else {
				// String urlString = null;
				// try {
				// urlString = EgmConstants.URL_GET_TOKEN
				// + "?id="
				// + EgmPrefHelper.getURSId(mActivity)
				// + "&params="
				// + EnctryUtil.encryptForAES("target=1&access_token=" +
				// accessToken,
				// EgmPrefHelper.getURSKey(mActivity));
				// } catch (Exception e) {
				// e.printStackTrace();
				// }
				// dologinGetExternalToken(urlString);
				// }
				// }
			}
		};
		mTencent.login(mActivity, "", baseUiListener);
	}

	/**
	 * QQ登陆回调接口
	 */
	private class BaseUiListener implements IUiListener {

		@Override
		public void onCancel() {
			Toast.makeText(mActivity, "取消授权", Toast.LENGTH_SHORT).show();
		}

		@Override
		public void onComplete(Object response) {
			doComplete((JSONObject) response);

		}

		protected void doComplete(JSONObject obj) {

		}

		@Override
		public void onError(UiError arg0) {
			Toast.makeText(mActivity, arg0.errorMessage, Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * Sina登陆
	 */
	private Oauth2AccessToken mAccessToken;
	private SsoHandler mSsoHandler;
	private WeiboAuth mWeiboAuth;

	public static final String SINA_CLIENT_ID = "876878023";
	public static final String SINA_REDIRECT_URI = "https://api.weibo.com/oauth2/default.html";
	public static final String SCOPE = "";

	/**
	 * 微博SDK登陆入口
	 */
	private void loginWithWeiboSDK() {
		mWeiboAuth = new WeiboAuth(mActivity, SINA_CLIENT_ID, SINA_REDIRECT_URI, SCOPE);
		mSsoHandler = new SsoHandler(mActivity, mWeiboAuth);
		mSsoHandler.authorize(new AuthListener());
	}

	/**
	 * 微博的回调接口
	 */
	class AuthListener implements WeiboAuthListener {

		@Override
		public void onComplete(Bundle values) {
			// 从 Bundle 中解析 Token
			mAccessToken = Oauth2AccessToken.parseAccessToken(values);
			if (mAccessToken.isSessionValid()) {
				//
				// EgmPrefHelper.putUid(mActivity, mAccessToken.getUid());
				// EgmPrefHelper.putAccessToken(mActivity,
				// mAccessToken.getToken());
				// EgmPrefHelper.putExpireIn(mActivity,
				// mAccessToken.getExpiresTime());
				//
				// String ursId = EgmPrefHelper.getURSId(mActivity);
				// if (TextUtils.isEmpty(ursId)) { // 还未初始化URS
				// EgmService.getInstance().doInitURS();
				// } else {
				// String urlString = null;
				// try {
				// urlString = EgmConstants.URL_GET_TOKEN
				// + "?id="
				// + EgmPrefHelper.getURSId(mActivity)
				// + "&params="
				// + EnctryUtil.encryptForAES("target=3&access_token=" +
				// mAccessToken.getToken(),
				// EgmPrefHelper.getURSKey(mActivity));
				// } catch (Exception e) {
				// e.printStackTrace();
				// }
				// dologinGetExternalToken(urlString);
				// }
			} else {
				String code = values.getString("code");
				String message = mActivity.getResources().getString(R.string.weibo_auth_error);
				if (!TextUtils.isEmpty(code)) {
					message = message + "\nObtained the code: " + code;
				}
				ToastUtil.showToast(mActivity, R.string.weibo_auth_exeption);
			}
		}

		@Override
		public void onCancel() {
			ToastUtil.showToast(mActivity, R.string.cancle_authority);
		}

		@Override
		public void onWeiboException(WeiboException e) {
			ToastUtil.showToast(mActivity, R.string.weibo_auth_exeption);
		}
	}

}
