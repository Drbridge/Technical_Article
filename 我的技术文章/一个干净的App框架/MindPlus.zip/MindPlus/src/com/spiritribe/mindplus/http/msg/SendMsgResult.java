package com.spiritribe.mindplus.http.msg;

/**
 * 发送消息返回
 *
 */
public class SendMsgResult {
	public MessageInfo messageInfo ;//消息信息
	public int tipsType;//0没有提示语，1答谢奖励，2答谢过期提示
	public int rewardTipsId;//活动答谢的Id
	public String rewardTips;//答谢的提示语
	public String thanks ;//答谢语句（发送礼物才有）
	public int usercp ;//增加的豪气值
	public int intimacy ;//增加的亲密度
	public int userLevel;//发送者的等级(发送礼物的消息才有值)
	public int matchType;//命中关键字类型 
	public String tips;//命中关键字提示语 
	
}
