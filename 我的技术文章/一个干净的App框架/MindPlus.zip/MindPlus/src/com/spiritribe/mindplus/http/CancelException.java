package com.spiritribe.mindplus.http;

import java.io.IOException;

public class CancelException extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
