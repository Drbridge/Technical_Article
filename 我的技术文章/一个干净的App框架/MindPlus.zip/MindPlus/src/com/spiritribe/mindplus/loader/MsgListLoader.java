package com.spiritribe.mindplus.loader;

import android.content.Context;
import android.database.Cursor;

import com.spiritribe.mindplus.http.msg.MsgDBManager;

public class MsgListLoader extends Loader {
	// 消息列表中加载可以使用
	public MsgListLoader(Context context) {
		super(context);
	}

	public MsgListLoader(Context context, long time, int pageNo, long receiveId, long senderId) {
		this(context);
		this.time = time;
		this.pageNo = pageNo;
		this.receiveId = receiveId;
		this.senderId = senderId;
	}

	private long time;
	private int pageNo;
	private long receiveId;
	private long senderId;

	@Override
	public Cursor getCursor() {

		// 查询对应的表格，找短消息列表
		Cursor cursor = MsgDBManager.getMsgList(time, pageNo, receiveId, senderId);
		return cursor;
	}
}
