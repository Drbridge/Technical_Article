package com.spiritribe.mindplus.http.msg;

import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.view.View;
import android.view.ViewGroup;

public class MsgListCursorAdapter extends CursorAdapter {

	private static final int TYPE_COUNT = 3;

	private static final int TYPE_MY = 0;
	private static final int TYPE_ANOTHER = 1;
	private static final int TYPE_SYSTEM = 2;

	private static final long MAX_FIRE_MSG_LIFE = 8 * 24 * 3600 * 1000;

	public MsgListCursorAdapter(Context context, Cursor c, boolean autoRequery) {
		super(context, c, false);

		init();
	}

	public MsgListCursorAdapter(Context context, Cursor c, int flags) {
		super(context, c, flags);

		init();
	}

	public MsgListCursorAdapter(Context context, Cursor c) {
		super(context, c, true);

		init();
	}

	private void init() {

	}

	@Override
	public void bindView(View arg0, Context arg1, Cursor arg2) {
		// TODO Auto-generated method stub

	}

	@Override
	public View newView(Context arg0, Cursor arg1, ViewGroup arg2) {
		// TODO Auto-generated method stub
		return null;
	}

}
