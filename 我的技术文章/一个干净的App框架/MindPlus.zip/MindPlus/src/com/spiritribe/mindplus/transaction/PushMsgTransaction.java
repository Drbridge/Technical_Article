package com.spiritribe.mindplus.transaction;

public class PushMsgTransaction extends Transaction {

	public PushMsgTransaction() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onTransact() {
		// TODO Auto-generated method stub
		
	}

}
