package com.spiritribe.mindplus.transaction.listener;

import com.spiritribe.mindplus.RecommendListInfo;
import com.spiritribe.mindplus.transaction.EgmBaseTransaction;

public class MplusCallBack {

	public void onGetRecSucess(int tid, int code, RecommendListInfo obj) {
	};

	public void onGetRecError(int tid, int code, String errMsg) {
	};

	public void onLoginSucess(int tid, int errCode, Object obj) {
	};

	public void onLoginError(int tid, int errCode, String errMsg) {
	};

	public void onSuccess(int type, int tid, int code, Object obj) {
		switch (type) {
		case EgmBaseTransaction.TRANSACTION_TYPE_GET_RECOMMEND:
			onGetRecSucess(tid, code, (RecommendListInfo) obj);
			break;
		case EgmBaseTransaction.TRANSACTION_LOGIN:
			onLoginSucess(tid, code, obj);
			break;
		default:
			break;
		}

	}

	public void onError(int type, int tid, int errCode, String errMsg, Object param) {
		switch (type) {
		case EgmBaseTransaction.TRANSACTION_TYPE_GET_RECOMMEND:
			onGetRecError(tid, errCode, errMsg);
			break;
		case EgmBaseTransaction.TRANSACTION_LOGIN:
			onLoginError(tid, errCode, errMsg);
			break;
		default:
			break;
		}
	}

}
