package com.spiritribe.mindplus.loader;

import android.content.Context;
import android.database.Cursor;

import com.spiritribe.mindplus.http.msg.LastMsgDBManager;

public class LastMsgInitLoader extends Loader{

	private int chooseType ;
	
	public LastMsgInitLoader(Context context) {
		super(context);
	}
	
	public LastMsgInitLoader(Context context , int chooseType ){
		this(context);
		this.chooseType = chooseType ;
	}
	
	@Override
	public Cursor getCursor() {
		Cursor cursor = LastMsgDBManager.getLastMsgListSortByRich(chooseType, false);
		return cursor ;
	}
}
