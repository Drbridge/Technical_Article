package com.spiritribe.mindplus.http.msg;

import java.util.List;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.spiritribe.mindplus.http.BaseDBProvider;
import com.spiritribe.mindplus.http.msg.MsgDBTables.LastMsgTable;
import com.spiritribe.mindplus.http.service.BaseService;



public class MsgDBProvider extends BaseDBProvider {
    public static final String AUTHORITY ="com.netease.date.msg";

    public MsgDBProvider() {
        super(BaseService.getServiceContext(),AUTHORITY, MsgDBTables.TableNames);
    }

    @Override
    public SQLiteOpenHelper getSQLiteOpenHelper() {
        return MsgDBOpenHelper.getInstance(getSQLiteContext());
    }
    
    public void bullInsert(List<ContentValues> list){
    	if(list == null || list.size() == 0){
    		return ;
    	}
    	SQLiteDatabase db = getSQLiteOpenHelper().getWritableDatabase();
    	
    	db.beginTransaction();
    	for(ContentValues value : list){
    		db.insert(LastMsgTable.TABLE_NAME, null, value);
    	}
    	db.setTransactionSuccessful();
    	db.endTransaction();
    }
}
