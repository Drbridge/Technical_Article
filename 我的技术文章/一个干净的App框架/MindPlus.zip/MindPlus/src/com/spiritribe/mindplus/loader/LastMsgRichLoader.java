package com.spiritribe.mindplus.loader;

import android.content.Context;
import android.database.Cursor;

import com.spiritribe.mindplus.http.msg.LastMsgDBManager;

/**
 * 按照豪气值进行排序
 */
public class LastMsgRichLoader extends Loader{
	
	private int chooseType ;
	
	public LastMsgRichLoader(Context context) {
		super(context);
	}
	
	public LastMsgRichLoader(Context context , int chooseType){
		this(context);
		this.chooseType = chooseType ;
	}

	@Override
	public Cursor getCursor() {
		Cursor cursor = LastMsgDBManager.getLastMsgListSortByRich(chooseType,true);
		return cursor ;
	}
}
