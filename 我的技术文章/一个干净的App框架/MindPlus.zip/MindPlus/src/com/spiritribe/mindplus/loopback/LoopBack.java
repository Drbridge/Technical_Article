package com.spiritribe.mindplus.loopback;

//本地的多界面刷新

public class LoopBack {
	// 传递的数据类型
	public int mType = -1;
	// 传递的数据
	public Object mData = null;

	public LoopBack() {

	}
}
