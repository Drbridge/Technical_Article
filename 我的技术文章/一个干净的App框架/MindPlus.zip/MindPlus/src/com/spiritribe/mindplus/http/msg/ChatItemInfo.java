package com.spiritribe.mindplus.http.msg;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.google.gson.Gson;

/**
 * 聊天列表返回数据项
 */
public class ChatItemInfo {
	public int notReadCount;// 未读消息个数
	public int notReadGiftValue;// 未读礼物总价值
	public MessageInfo message;// 消息内容
	public ChatItemUserInfo anotherUserInfo;// 对方的userinfo

	public ChatItemInfo() {
		message = new MessageInfo();
		anotherUserInfo = new ChatItemUserInfo();
	}

	public static String toJson(ChatItemInfo info) {
		if (info == null) {
			return null;
		}
		Gson gson = new Gson();
		String result = gson.toJson(info);
		return result;
	}

	public static final String FILE_NAME = "chatlist.json";

}
