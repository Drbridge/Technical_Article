package com.spiritribe.mindplus.transaction.type;

public interface SizeObserver {

	public void onGetStoreSizeResult(StoreSizeResult result);
	
}
