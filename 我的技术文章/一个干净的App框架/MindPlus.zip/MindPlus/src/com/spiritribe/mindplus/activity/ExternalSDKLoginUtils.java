package com.spiritribe.mindplus.activity;

import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import com.spiritribe.mindplus.R;
import com.spiritribe.mindplus.transaction.type.EgmServiceCode;
import com.spiritribe.mindplus.utils.EgmConstants;
import com.spiritribe.mindplus.utils.EgmProtocolConstants;
import com.spiritribe.mindplus.utils.EnctryUtil;
import com.spiritribe.mindplus.utils.ToastUtil;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.SendAuth;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;

/**
 * @author lishang SDK三方登陆流程类似，所以统一入口，减少重复CallBack
 *         微博:可以直接获取AccessTOken，所以直接请求token+username
 *         微信：无法直接获取Token，需要首先获取Code，然后请求Token，之后流程类似 本来做成Activity
 *         但是微信无法用onActivityresutlt监听，所以采用仿activity
 */
public class ExternalSDKLoginUtils {
	//
	// private ActivityEngagementBase mActivity;
	// /**
	// * 定位信息
	// */
	// private EgmLocationManager mLocation;
	//
	// /**
	// * Sina登陆
	// */
	// private Oauth2AccessToken mAccessToken;
	// private SsoHandler mSsoHandler;
	// private WeiboAuth mWeiboAuth;
	// public static final String SINA_CLIENT_ID = "876878023";
	// public static final String SINA_REDIRECT_URI =
	// "https://api.weibo.com/oauth2/default.html";
	// public static final String SCOPE = "";
	// /**
	// * 微信登陆
	// */
	// private static final String WEIXIN_APP_ID = "wxb326c9b1691d5dfc";
	// /**
	// * 登陆类型KEY
	// */
	// public static final String EXTERNAL_LOGIN_KEY = "external_login_type";
	// /**
	// * 登陆类型
	// */
	// private int mExternalLoginType;
	// /**
	// * 微信Token信息
	// */
	// private WXinTokenInfo mWXinTokenInfo;
	// /**
	// * QQ Token信息
	// */
	// private String mQQTokenInfo;
	//
	// /**
	// * 单例
	// */
	// private static ExternalSDKLoginUtils mInstace;
	//
	// public static synchronized ExternalSDKLoginUtils
	// getInstacne(ActivityEngagementBase context) {
	//
	// if (mInstace == null) {
	// mInstace = new ExternalSDKLoginUtils(context);
	// }
	// return mInstace;
	// }
	//
	// /**
	// * @param 构造函数
	// */
	// private ExternalSDKLoginUtils(ActivityEngagementBase context) {
	// mActivity = context;
	// }
	//
	// public void login(ActivityEngagementBase context, int type) {
	// mExternalLoginType = type;
	// mActivity=context;
	// init();
	// }
	//
	// protected void init() {
	// mLocation = new EgmLocationManager(mActivity);
	// loginWithExternalChannel(mExternalLoginType);
	// EgmService.getInstance().addListener(mCallBack);
	// }
	//
	// protected void clear() {
	// EgmService.getInstance().removeListener(mCallBack);
	// mExternalLoginType = -1;
	// mLocation.stop();
	// }
	//
	// /**
	// * 停止定位
	// */
	// protected void onDestroy() {
	// if (mExternalLoginType == EgmProtocolConstants.AccountType.WEIBO
	// || mExternalLoginType == EgmProtocolConstants.AccountType.WEIXIN
	// || mExternalLoginType == EgmProtocolConstants.AccountType.QQ) {
	// clear();
	// }
	// }
	//
	// /**
	// * 微博的回调接口
	// */
	// class AuthListener implements WeiboAuthListener {
	//
	// @Override
	// public void onComplete(Bundle values) {
	// // 从 Bundle 中解析 Token
	// mAccessToken = Oauth2AccessToken.parseAccessToken(values);
	// if (mAccessToken.isSessionValid()) {
	// EgmPrefHelper.putUid(mActivity, mAccessToken.getUid());
	// EgmPrefHelper.putAccessToken(mActivity, mAccessToken.getToken());
	// EgmPrefHelper.putExpireIn(mActivity, mAccessToken.getExpiresTime());
	//
	// String ursId = EgmPrefHelper.getURSId(mActivity);
	// if (TextUtils.isEmpty(ursId)) { // 还未初始化URS
	// EgmService.getInstance().doInitURS();
	// } else {
	// String urlString = null;
	// try {
	// urlString = EgmConstants.URL_GET_TOKEN
	// + "?id="
	// + EgmPrefHelper.getURSId(mActivity)
	// + "&params="
	// + EnctryUtil.encryptForAES(
	// "target=3&access_token=" + mAccessToken.getToken(),
	// EgmPrefHelper.getURSKey(mActivity));
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// dologinGetExternalToken(urlString);
	// }
	// } else {
	// String code = values.getString("code");
	// String message =
	// mActivity.getResources().getString(R.string.weibo_auth_error);
	// if (!TextUtils.isEmpty(code)) {
	// message = message + "\nObtained the code: " + code;
	// }
	// ToastUtil.showToast(mActivity, R.string.weibo_auth_exeption);
	// }
	// }
	//
	// @Override
	// public void onCancel() {
	// ToastUtil.showToast(mActivity,R.string.cancle_authority);
	// }
	//
	// @Override
	// public void onWeiboException(WeiboException e) {
	// ToastUtil.showToast(mActivity, R.string.weibo_auth_exeption);
	// }
	// }
	//
	//
	// /**
	// * 仿造Activity流程供上层Activity回调
	// */
	// protected void onActivityResult(int requestCode, int resultCode, Intent
	// data) {
	//
	// if (requestCode == REQUEST_CODE_SELECT_SEX) {
	// // 从选性别界面获取性别后再跳去注册界面
	// int sexType = EgmConstants.SexType.Female;
	// if (data != null) {
	// Bundle extra = data.getExtras();
	// if (extra != null) {
	// sexType = extra.getInt(ActivityWelcome.EXTRA_SEX_RESULT);
	// gotoRegisterDetail(sexType);
	// mActivity.finish();
	// }
	// }
	// return;
	// }
	//
	// // 只有QQ、微博有回调，选性别不回调，微信不回调
	// switch (mExternalLoginType) {
	// case EgmProtocolConstants.AccountType.QQ:
	// mTencent.onActivityResult(requestCode, resultCode, data);
	// break;
	// case EgmProtocolConstants.AccountType.WEIBO:
	// if (mSsoHandler != null) {
	// mSsoHandler.authorizeCallBack(requestCode, resultCode, data);
	// }
	// break;
	// default:
	// break;
	// }
	//
	// }
	//
	//
	// /** 进入选择性别界面（欢迎页） */
	// private final int REQUEST_CODE_SELECT_SEX = 1;// 选择性别
	// private String mUserName;
	//
	// private void gotoSelectSex() {
	// ActivityWelcome.startActivityForResult(mActivity,
	// REQUEST_CODE_SELECT_SEX,
	// ActivityWelcome.TYPE_LOGIN);
	// }
	//
	// /** 进入推荐页面 */
	// private void gotoRecommend(int portraitStatus) {
	// ActivityHome.startActivity(mActivity, false, portraitStatus);
	// }
	//
	// /** 前往补充资料界面 */
	// private void gotoRegisterDetail(int sexType, int loginType) {
	// ActivityRegisterDetail.startActivity(mActivity, sexType, mUserName, "",
	// loginType, true);
	// }
	//
	// /** 前往补充资料界面 */
	// public void gotoRegisterDetail(int sexType) {
	// ActivityRegisterDetail.startActivity(mActivity, sexType, mUserName, "",
	// mExternalLoginType,
	// true);
	// }
	// EgmCallBack mCallBack = new EgmCallBack() {
	//
	// public void onInitURS(int transactionId, String[] data) {
	// String params=null;
	// switch (mExternalLoginType) {
	// case EgmProtocolConstants.AccountType.YiXin:
	// break;
	// case EgmProtocolConstants.AccountType.QQ:
	// params="target=1&access_token=" + mQQTokenInfo;
	// break;
	// case EgmProtocolConstants.AccountType.WEIBO:
	// params="target=3&access_token=" + mAccessToken.getToken();
	// break;
	// case EgmProtocolConstants.AccountType.WEIXIN:
	// params="target=13&access_token=" + mWXinTokenInfo.access_token
	// +"&openid="+mWXinTokenInfo.openid;
	// break;
	// default:
	// ToastUtil.showToast(mActivity, R.string.login_type_erro);
	// return;
	// }
	// // 整合参数
	// try {
	// String key = EgmPrefHelper.getURSKey(mActivity);
	// String urlString = EgmConstants.URL_GET_TOKEN
	// + "?id="
	// + EgmPrefHelper.getURSId(mActivity)
	// + "&params="
	// + EnctryUtil.encryptForAES( params, key);
	// dologinGetExternalToken(urlString);
	// } catch (Exception e) {
	// e.printStackTrace();
	// ToastUtil.showToast(mActivity, R.string.illegal_arguments);
	// }
	// }
	//
	// public void onInitURSError(int transactionId, int errCode, String err) {
	// ToastUtil.showToast(mActivity, err);
	// };
	//
	// @Override
	// public void onLoginGetUserInfo(int transactionId, LoginUserInfo
	// loginUserInfo) {
	//
	// ToastUtil.showToast(mActivity,R.string.reg_tip_login_success);
	// gotoRecommend(loginUserInfo.userInfo.portraitStatus);
	// mActivity.stopWaiting();
	// };
	//
	// @Override
	// public void onLoginGetUsrInfoError(int transactionId, int errCode, String
	// err) {
	// mActivity.stopWaiting();
	//
	// switch (errCode) {
	// case EgmServiceCode.TRANSACTION_COMMON_EXTERNAL_REGISTER_NOT_FINISH:
	// if (EngagementApp.getAppInstance().getGender() < 0) {
	// gotoSelectSex();
	// return;
	// } else {
	// gotoRegisterDetail(EngagementApp.getAppInstance().getGender(),mExternalLoginType);
	// }
	// break;
	//
	// case EgmServiceCode.TRANSACTION_COMMON_NOT_REGISTER:
	// ToastUtil.showToast(mActivity, R.string.reg_tip_no_register_error);
	// break;
	// case EgmServiceCode.TRANSACTION_COMMON_USER_BLOCK:
	// ToastUtil.showToast(mActivity, err);
	// break;
	// default:
	// ToastUtil.showToast(mActivity, err);
	// break;
	// }
	// }
	//
	// public void onGetExternalLoginInfoSucess(int transactionId,
	// ExternalTokenInfo info) {
	// if (info != null && !TextUtils.isEmpty(info.userName))
	// mUserName = info.userName;
	// };
	//
	// public void onGetExternalLoginInfoError(int transactionId, int errCode,
	// String errStr) {
	// mActivity.stopWaiting();
	// };
	// public void onGetWXinTokenSucess(int transactionId, WXinTokenInfo info) {
	//
	// EgmPrefHelper.putAccessToken(mActivity, info.access_token);
	// // EgmPrefHelper.putExpireIn(mActivity, info.expires_in);
	//
	// mWXinTokenInfo = info;
	// String ursId = EgmPrefHelper.getURSId(mActivity);
	// if (TextUtils.isEmpty(ursId)) { // 还未初始化URS
	// EgmService.getInstance().doInitURS();
	// } else {
	// String urlString = null;
	// String params= "target=13&access_token="
	// + mWXinTokenInfo.access_token
	// +"&openid="+mWXinTokenInfo.openid;
	// try {
	// urlString = EgmConstants.URL_GET_TOKEN
	// + "?id="
	// + EgmPrefHelper.getURSId(mActivity)
	// + "&params="
	// + EnctryUtil.encryptForAES(params, EgmPrefHelper.getURSKey(mActivity));
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// dologinGetExternalToken(urlString);
	// }
	//
	// };
	//
	// public void onGetWXinTokenError(int transactionId, int errCode, String
	// errStr) {
	// ToastUtil.showToast(mActivity, "error");
	// };
	//
	// };
	//
	// /**
	// * @param 微信SDK登录入口 获取code实际是token，但不是AccessToken
	// */
	// public void loginWithWXinSDK(Context context) {
	//
	// IWXAPI iwxapi = WXAPIFactory.createWXAPI(mActivity, WEIXIN_APP_ID, true);
	// try {
	// boolean ret = iwxapi.registerApp(WEIXIN_APP_ID);
	// if (ret) {
	// SendAuth.Req req = new SendAuth.Req();
	// req.scope = "snsapi_userinfo";
	// req.state = "wechat_sdk_demo_test";
	// iwxapi.sendReq(req);
	// } else {
	// ToastUtil.showToast(mActivity, R.string.app_id_illegal);
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	//
	// }
	//
	// /**
	// * 微博SDK登陆入口
	// */
	// private void loginWithWeiboSDK() {
	// mWeiboAuth = new WeiboAuth(mActivity, SINA_CLIENT_ID, SINA_REDIRECT_URI,
	// SCOPE);
	// mSsoHandler = new SsoHandler(mActivity, mWeiboAuth);
	// mSsoHandler.authorize(new AuthListener());
	// }
	//
	// /**
	// * QQSDK登陆入口
	// */
	// private Tencent mTencent;
	// private final String QQ_LOGIN_APP_ID="1102305277";
	//
	// private void loginWithQQSDK() {
	// mTencent = Tencent.createInstance(QQ_LOGIN_APP_ID,
	// mActivity.getApplicationContext());
	// // if (!mTencent.isSessionValid())
	// // 每次点击都重新登录
	// BaseUiListener baseUiListener = new BaseUiListener() {
	//
	// @Override
	// protected void doComplete(JSONObject obj) {
	// if (null == obj)
	// return;
	//
	// String accessToken = (String)obj.opt("access_token");
	// if (!TextUtils.isEmpty(accessToken)) {
	// mQQTokenInfo = accessToken;
	// String ursId = EgmPrefHelper.getURSId(mActivity);
	// if (TextUtils.isEmpty(ursId)) { // 还未初始化URS
	// EgmService.getInstance().doInitURS();
	// } else {
	// String urlString = null;
	// try {
	// urlString = EgmConstants.URL_GET_TOKEN
	// + "?id="
	// + EgmPrefHelper.getURSId(mActivity)
	// + "&params="
	// + EnctryUtil.encryptForAES("target=1&access_token="
	// + accessToken, EgmPrefHelper.getURSKey(mActivity));
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// dologinGetExternalToken(urlString);
	// }
	// }
	// }
	// };
	// mTencent.login(mActivity, "", baseUiListener);
	// }
	// /**
	// * @param 三方登陆入口
	// */
	// private void loginWithExternalChannel(int type) {
	// switch (type) {
	// case EgmProtocolConstants.AccountType.YiXin:
	// break;
	// case EgmProtocolConstants.AccountType.QQ:
	// loginWithQQSDK();
	// break;
	// case EgmProtocolConstants.AccountType.WEIBO:
	// loginWithWeiboSDK();
	// break;
	// case EgmProtocolConstants.AccountType.WEIXIN:
	// loginWithWXinSDK(mActivity);
	// break;
	// default:
	// ToastUtil.showToast(mActivity, R.string.login_type_erro);
	// return;
	// }
	// }
	//
	//
	//
	// /**
	// * QQ登陆回调接口
	// */
	// private class BaseUiListener implements IUiListener {
	//
	// @Override
	// public void onCancel() {
	// Toast.makeText(mActivity, R.string.cancle_authority,
	// Toast.LENGTH_SHORT).show();
	// }
	//
	// @Override
	// public void onComplete(Object response) {
	// doComplete((JSONObject)response);
	//
	// }
	//
	// protected void doComplete(JSONObject obj) {
	//
	// }
	//
	// @Override
	// public void onError(UiError arg0) {
	// Toast.makeText(mActivity, arg0.errorMessage, Toast.LENGTH_SHORT).show();
	// }
	// }
	//
	// public int getExternalLoginType() {
	// return mExternalLoginType;
	//
	// }
	//
	// private void dologinGetExternalToken(String urlString) {
	// EgmService.getInstance().doGetExternalLoginInfo(urlString, mLocation);
	// mActivity.showWatting(mActivity.getString(R.string.reg_tip_logining));
	// }
	//
	//
	// /**
	// * qq 分享
	// * @param context
	// * @param title 标题
	// * @param targetUrl 跳转地址
	// * @param imageUrl 图片url
	// * @param summary 摘要
	// * @param appName 应用名
	// */
	// public void shareToQQ(Context context, String title, String targetUrl,
	// String imageUrl,
	// String summary, String appName) {
	// if (mTencent == null) {
	// mTencent = Tencent.createInstance(QQ_LOGIN_APP_ID,
	// mActivity.getApplicationContext());
	// }
	// Bundle bundle = new Bundle();
	// bundle.putString("title", title);
	// bundle.putString("imageUrl", imageUrl);
	// bundle.putString("targetUrl", targetUrl);
	// bundle.putString("summary", summary);
	// bundle.putString("appName", appName);
	// mTencent.shareToQQ(mActivity, bundle, new BaseUiListener());
	// }
}
