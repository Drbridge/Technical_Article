package com.spiritribe.mindplus.transaction.type;

public interface Priority {
	public static final int LOW = 0; // 先入先出策略
	public static final int NORMAL = 1; // 先入先出策略
	public static final int HIGH = 2; // 先入先入策略
	public static final int HIGHER = 3; // 先入先入策略
	public static final int EMERGENCY = 4; // 先入先入策略 
	
	public static final int HRADER_TAG = 0x0100; // 头部标记
	
	/**
	 * 设置优先级
	 * @param priority
	 */
	public void setPriority(int priority);
	
	/**
	 * 获取优先级
	 * @param priority
	 */
	public int getPriority();
	
	/**
	 * 分组ID
	 */
	public int getGroupID();
}