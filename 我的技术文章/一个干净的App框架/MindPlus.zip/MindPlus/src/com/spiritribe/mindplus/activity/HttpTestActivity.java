package com.spiritribe.mindplus.activity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;

import com.spiritribe.mindplus.R;
import com.spiritribe.mindplus.RecommendListInfo;
import com.spiritribe.mindplus.http.file.FileDownloadListener;
import com.spiritribe.mindplus.http.file.FileDownloadManager;
import com.spiritribe.mindplus.http.image.ProgerssImageView;
import com.spiritribe.mindplus.http.service.MplusService;
import com.spiritribe.mindplus.transaction.listener.MplusCallBack;
import com.spiritribe.mindplus.utils.ToastUtil;

public class HttpTestActivity extends MplusBaseAcvitiy {

	private String urlString = "http://yimg.nos.netease.com/images/rank/v1062";
	private ProgerssImageView imageView;
	private Activity mActivity;

	private Handler mHandler;
	private String[] imgStrings = { "http://yimg.nos.netease.com/images/vip/1",
			"http://yimg.nos.netease.com/images/vip/2", "http://yimg.nos.netease.com/images/vip/3",
			"http://yimg.nos.netease.com/images/vip/4", "http://yimg.nos.netease.com/images/vip/5",
			"http://yimg.nos.netease.com/images/vip/6", "http://yimg.nos.netease.com/images/vip/7",
			"http://yimg.nos.netease.com/images/vip/8", "http://yimg.nos.netease.com/images/vip/9" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mActivity = this;
		setContentView(R.layout.activity_main);
		MplusService.getInstance().addListener(mCallBack);

		mHandler = new Handler();
		PullListViewTestTestActivity.startActivity(this);
	}

	public static void startActivity(Context context) {
		Intent intent = new Intent(context, HttpTestActivity.class);
		if (!(context instanceof Activity)) {
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		}
		context.startActivity(intent);
	}

	private void iniView() {
		imageView = (ProgerssImageView) findViewById(R.id.img);

		findViewById(R.id.get).setOnClickListener(new OnClickListener() {

			private ListView mListView;

			@Override
			public void onClick(View v) {
				if (true)
				// 普通的Json String数据获取
				{
					MplusService.getInstance().doGetRecommend(false);
					showWatting("", "请稍后...");
				}

				if (false) { // 图片下载
					imageView.setLoadingImage("http://yimg.nos.netease.com/images/rank/v1062");
				}
				// 文件下载
				// 下载的时候不要自己设置路径之类的了，没必要，设置了反而不行，注意使用方法，后续优化
				if (false) {
					FileDownloadManager.getInstance().downloadFile(imgStrings[new Random().nextInt(9)], "", "",
							new FileDownloadListener() {

								@Override
								public void onSuccess(String path) {
									imageView.setLoadingImage(path);
									Calendar c1 = Calendar.getInstance();
									SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd H:m:s");
									Log.v("lishang", "" + format.format(c1.getTime()));
								}

								@Override
								public void onProgress(long current, long total, final int percent, int speed) {
									Calendar c1 = Calendar.getInstance();
									SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd H:m:s");
									Log.v("lishang", " percent " + percent + "" + format.format(c1.getTime()));
								}

								@Override
								public void onFailed(String err, int errCode) {

								}
							});
				}
				mListView = (ListView) findViewById(R.id.listview);
				// 多条List
				if (false) {
					mListView.setAdapter(new BaseAdapter() {

						@Override
						public View getView(final int position, View convertView, ViewGroup parent) {

							if (convertView == null) {
								View rooView = LayoutInflater.from(mActivity).inflate(R.layout.item_img, null);
								final ProgerssImageView imageView = (ProgerssImageView) rooView
										.findViewById(R.id.img_item);
								imageView.setLoadingImage(imgStrings[position]);
								Log.v("lishang", "" + position);
								convertView = rooView;
							} else {
								ProgerssImageView imageView = (ProgerssImageView) convertView
										.findViewById(R.id.img_item);
								imageView.setLoadingImage(imgStrings[position]);
							}
							return convertView;
						}

						@Override
						public long getItemId(int position) {
							// TODO Auto-generated method stub
							return position;
						}

						@Override
						public Object getItem(int position) {
							return null;
						}

						@Override
						public int getCount() {
							int count = imgStrings.length;
							Log.v("lishang", "" + count);
							return imgStrings.length;
						}
					});
				}
			}
		});
		// 发送消息或者上传的处理
		findViewById(R.id.btn_login).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				MplusService.getInstance().doLogin("ceshi", "ceshi");
			}
		});
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

		iniView();
	}

	/**
	 * 不要采用匿名类，采用内部成员，这样能防止弱引用的时候被回收
	 */
	private MplusCallBack mCallBack = new MplusCallBack() {
		@Override
		public void onGetRecSucess(int tid, int code, RecommendListInfo obj) {
			stopWaiting();
			super.onGetRecSucess(tid, code, obj);
			ToastUtil.showToast(HttpTestActivity.this, obj.list.get(0).toString());
		}

		public void onLoginSucess(int tid, int errCode, Object obj) {
		};

		public void onLoginError(int tid, int errCode, String errMsg) {
			stopWaiting();
			ToastUtil.showToast(mActivity, "" + errCode + errMsg);
		};

	};

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		MplusService.getInstance().removeListener(mCallBack);
	}
}
