package com.spiritribe.mindplus.http.msg;

import java.io.File;
import java.net.URI;

import android.text.TextUtils;
import android.webkit.URLUtil;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.spiritribe.mindplus.http.ImageUtil;
import com.spiritribe.mindplus.http.THttpRequest;
import com.spiritribe.mindplus.http.accout.ManagerAccount;
import com.spiritribe.mindplus.transaction.EgmBaseTransaction;
import com.spiritribe.mindplus.transaction.type.EgmServiceCode;
import com.spiritribe.mindplus.utils.EgmConstants;
import com.spiritribe.mindplus.utils.EgmProtocol;
import com.spiritribe.mindplus.utils.EgmProtocolConstants;
import com.spiritribe.mindplus.utils.EgmUtil;

public class SendMsgTransaction2 extends EgmBaseTransaction {

	private MessageInfo mMsgInfo;
	private String mFilePath;
	private String mFilePathTemp;

	public SendMsgTransaction2(MessageInfo info, String filePath) {
		super(TRANSACTION_SEND_MSG);
		mMsgInfo = info;
		mFilePath = filePath;
	}

	@Override
	public void onTransact() {
		if (mMsgInfo.type == EgmProtocolConstants.MSG_TYPE.MSG_TYPE_LOCAL_PIC) {// 图片压缩
			if (!TextUtils.isEmpty(mFilePath)) {
				File file = null;
				String path = null;

				if (URLUtil.isFileUrl(mFilePath)) {
					file = new File(URI.create(mFilePath));
				} else {
					file = new File(mFilePath);
				}

				path = file.getPath();

				String tempFile = EgmUtil.getCacheDir().toString();
				tempFile += System.currentTimeMillis() + "_temp.jpg";

				if (ImageUtil.saveResizeTmpFile(path, tempFile, EgmProtocolConstants.SIZE_MAX_PICTURE,
						EgmProtocolConstants.PIC_QULITY)) {
					File fileTemp = new File(tempFile);
					if (fileTemp.exists()) {
						mFilePathTemp = tempFile;
					}
				}
			}
		}

		THttpRequest request = EgmProtocol.getInstance().createSendMsg(mMsgInfo,
				TextUtils.isEmpty(mFilePathTemp) ? mFilePath : mFilePathTemp);
		sendRequest(request);
	}

	@Override
	protected void onEgmTransactionSuccess(int code, Object obj) {
		SendMsgResult result = null;
		if (obj != null && obj instanceof JsonElement) {
			Gson gson = new Gson();
			JsonElement json = (JsonElement) obj;
			result = gson.fromJson(json, SendMsgResult.class);
		}

		if (result == null) {
			// onEgmTransactionError(EgmServiceCode.ERR_CODE_DATA_PARSE_EXCEPTION,
			// ErrorToString.getString(EgmServiceCode.ERR_CODE_DATA_PARSE_EXCEPTION));
			return;
		}

		if (code == EgmServiceCode.TRANSACTION_CHAT_KEYWORDS_BLOCKED) {
			// 因关键词过滤导致消息发送失败，需要返回内容,同时返回的tips及matchType需要记录在消息数据库
			MsgAttach attach;
			if (!TextUtils.isEmpty(mMsgInfo.attach)) {
				attach = MsgAttach.toMsgAttach(mMsgInfo.attach);
			} else {
				attach = new MsgAttach();
			}
			attach.matchType = result.matchType;
			attach.tips = result.tips;
			mMsgInfo.attach = MsgAttach.toJsonString(attach);
			onEgmTransactionError(code, "");
			return;
		}
		// 发送成功
		MessageInfo resultMsg = result.messageInfo;
		mMsgInfo.status = EgmConstants.Sending_State.SEND_SUCCESS;

		// changed by echo_chen 2014-07-22 修复对方黑名单，消息一直不显示发送成功
		if (resultMsg != null) {
			resultMsg.msgContent = PDEEngine.PXDecrypt(resultMsg.msgContent);

			mMsgInfo.msgId = resultMsg.msgId;

			mMsgInfo.extraString = resultMsg.extraString;
			mMsgInfo.extra = resultMsg.extra;
		}

		MsgDBManager.updataMsgState(mMsgInfo, resultMsg == null ? mMsgInfo.time : resultMsg.time);
		if (resultMsg != null) {
			mMsgInfo.time = resultMsg.time;
		}
		LastMsgDBManager.handleNewMsg(mMsgInfo);

		OnSendFinished();

		notifyMessage(EgmServiceCode.TRANSACTION_SUCCESS, result);
	}

	@Override
	protected void onEgmTransactionError(int errCode, Object obj) {
		OnSendError();
		OnSendFinished();
		super.onEgmTransactionError(errCode, obj);
	}

	private void OnSendError() {
		mMsgInfo.status = EgmConstants.Sending_State.SEND_FAIL;
		mMsgInfo.msgId = -mMsgInfo.time;

		MsgDBManager.updataMsgState(mMsgInfo);
		LastMsgDBManager.handleNewMsg(mMsgInfo);
	}

	private void OnSendFinished() {
		if (!TextUtils.isEmpty(mFilePathTemp)) {
			File file = new File(mFilePathTemp);
			if (file.exists()) {
				file.delete();
			}
		}
	}

}
